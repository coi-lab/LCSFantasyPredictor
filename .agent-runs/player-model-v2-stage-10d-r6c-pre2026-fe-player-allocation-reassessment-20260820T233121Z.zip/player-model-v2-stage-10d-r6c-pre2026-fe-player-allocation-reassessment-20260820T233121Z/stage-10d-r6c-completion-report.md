# Stage 10D-R6C: Pre-2026 Fantasy Environment Player Allocation Reassessment Completion Report

## VERDICT
```text
STAGE_10D_R6C_S30_SHARE_REMAINS_BEST
```

---

## A. Parent State
`AC_FE_SYM` with `S30_share` allocation (history_window = 5, alpha_E = 1.690769) remains the operational baseline. `AC` is permanently retained as reference baseline.

---

## B. Why Allocation Was Reassessed
In Stage 10D-R6B, evidence showed that team-level Fantasy Environment adjustments were highly effective (-0.3225 Team MAE / -1.46%), while player-level gains were smaller (-0.0317 Player MAE / -0.63%). Stage 10D-R6C investigated whether distributing team delta_E using historical kill participation (KP) rather than baseline fantasy scoring share (S30_share) would improve player projections.

---

## C. Allocation Arms Evaluated
- **ARM 0 (AC):** Unadjusted opponent-adjusted baseline (Player MAE = 5.039659).
- **ARM 1 (ALLOC_S30):** Promoted baseline allocation using projected baseline fantasy share (Player MAE = 5.007919).
- **ARM 2 (ALLOC_KP):** Pure kill-participation share allocation (Player MAE = 5.006824, Delta = -0.001095).
- **ARM 3 (ALLOC_BLEND_50):** Fixed 50/50 convex combination of S30 and KP shares (Player MAE = 5.007263, Delta = -0.000657).
- **ARM 4 (ALLOC_BLEND_SEL):** Training-selected blend (lambda = 0.75 chosen in all folds) (Player MAE = 5.007539, Delta = -0.000381).

---

## D. Cutoff-Safe KP Construction & Fallback Safety
- Historical player kill participation is strictly cutoff-safe (0 same-lock violations, 0 future violations).
- Fallback hierarchy: (1) Player recent KP (history >= 1) -> (2) Role KP prior -> (3) S30_share.
- Cold-start players exhibited zero disruption (MAE delta < 0.001 across all history depth bins).

---

## E. Team Invariance Audit
```text
Max absolute team prediction difference across all allocation arms: 0.0000000000
```
Every allocation candidate preserves exact team-level delta_E accounting:
sum_i allocation_share_i = 1.0 => sum_i delta_E_player_i = delta_E_team

---

## F. Walk-Forward Results Across Historical Folds
- **Fold 1 (2023):** ALLOC_S30 = 4.956811 | ALLOC_KP = 4.956081 (d = -0.000731) | BLEND_SEL = 4.956627 (d = -0.000184)
- **Fold 2 (2024):** ALLOC_S30 = 5.048371 | ALLOC_KP = 5.049684 (d = +0.001313) | BLEND_SEL = 5.048342 (d = -0.000029)
- **Fold 3 (2025):** ALLOC_S30 = 5.050025 | ALLOC_KP = 5.045798 (d = -0.004226) | BLEND_SEL = 5.048949 (d = -0.001075)

---

## G. Role Effects & Trade-offs
- Pure KP allocation improves MID (-0.0130 MAE) and TOP (-0.0031 MAE), but systematically worsens BOT (+0.0092 MAE) and SUP (+0.0028 MAE).
- Training-selected blend (lambda = 0.75) moderates role shifts, but yields only a microscopic -0.000381 MAE improvement (-0.007%), which represents pure measurement noise.

---

## H. Advancement Decision
```text
RETAIN_S30_SHARE_ALLOCATION
```
In accordance with Advancement Gate 20 ("If improvement is tiny and unstable, retain S30_share for simplicity"), no new allocation candidate is promoted. `S30_share` remains the most parsimonious, robust, and effective allocation mechanism.

---

## I. 2026 Firewall
```text
2026 was not used for player-KP construction.
2026 was not used for allocation selection.
2026 candidate performance was not evaluated.
The 2026 tournament was not rerun.
```

---

## J. Operational Model Status
```text
The 2026-proven S30-share AC_FE (alpha = 1.690769, window = 5) is completely frozen and retained as the primary operational baseline.
```

---

## K. Next Node
```text
FREEZE_AC_FE_SYM_S30_AS_CURRENT_OPERATIONAL_BASELINE_PENDING_FUTURE_UNSEEN_HOLDOUT
```
