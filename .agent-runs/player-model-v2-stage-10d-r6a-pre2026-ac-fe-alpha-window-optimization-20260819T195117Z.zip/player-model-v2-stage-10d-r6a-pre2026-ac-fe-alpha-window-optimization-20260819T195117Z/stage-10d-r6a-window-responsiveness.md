# Stage 10D-R6A: Window Responsiveness Diagnostic

## Summary of Window Properties Across Pre-2026 Data

| Metric / Dimension | Window 3 | Window 5 (Promoted) | Window 8 | Window 10 |
| :--- | :--- | :--- | :--- | :--- |
| **FE1_centered Std Dev** | 2.5813 | 2.1185 | 1.9196 | 1.8607 |
| **Cold-Start Periods (N=0)** | 298 | 298 | 298 | 298 |
| **Fitted Alpha Mean (Folds 1-3)** | 0.8914 | 1.7296 | 1.7620 | 1.9197 |
| **Alpha Coeff of Variation (%)** | 10.04% | 2.33% | 20.95% | 15.94% |
| **Pooled Player MAE** | 5.020290 | 5.008584 (Base: 5.007919) | 5.019959 | 5.013208 |
| **Pooled Team MAE** | 21.955689 | 21.768075 (Base: 21.765259) | 21.806075 | 21.795410 |

## Qualitative Findings
1. **Window 3:** High responsiveness to single-game noise; lower alpha scale factor (0.81–0.98), but higher pooled error (MAE 5.020 vs 5.008).
2. **Window 5 (Promoted):** Exceptional sweet spot balancing rapid adaptation to current split form with combat sample stability. Alpha scale is extremely consistent (1.69 to 1.77, CV = 2.33%). Outperforms all other windows.
3. **Window 8 & 10:** Sluggish responsiveness to team tactical changes early in splits; over-smooths recent playstyle shifts.
