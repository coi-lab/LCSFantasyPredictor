# Stage 10D-R6A: Pre-2026 AC_FE Alpha and History-Window Optimization Completion Report

## VERDICT
```text
STAGE_10D_R6A_PROMOTED_AC_FE_REMAINS_BEST_TIER1_CONFIGURATION
```

---

## A. Parent Baseline
`AC_FE` (alpha_E = 1.690769, history_window = 5) is the promoted primary operational baseline from Stage 10D-R5G-R5H. `AC` is retained permanently as reference baseline.

---

## B. Optimization Search
- **Parameter Dimensions:** alpha_E >= 0, history_window in {3, 5, 8, 10} completed games.
- **Search Space:** Closed-form least squares on pre-lock team residuals across expanding walk-forward folds.
- **Invariants:** Zero intercept, FE1 formula unchanged, S30_share distribution unchanged.

---

## C. Walk-Forward Method
Expanding historical folds strictly excluding evaluation-year targets and completely excluding 2026:
- Fold 1: Fit <= 2022 -> Evaluate 2023 (658 player rows, 130 team periods)
- Fold 2: Fit <= 2023 -> Evaluate 2024 (380 player rows, 76 team periods)
- Fold 3: Fit <= 2024 -> Evaluate 2025 (362 player rows, 71 team periods)
- **Total Pooled OOS Rows:** 1,400 player rows / 277 team periods.

---

## D. Alpha Stability
Fold-specific fitted alpha coefficients across candidate windows:
- **Window 3:** Fold 1 = 0.874214, Fold 2 = 0.811697, Fold 3 = 0.988187 (Mean = 0.8914, CV = 10.05%)
- **Window 5:** Fold 1 = 1.771230, Fold 2 = 1.690769, Fold 3 = 1.726936 (Mean = 1.7296, **CV = 2.33%**)
- **Window 8:** Fold 1 = 2.187958, Fold 2 = 1.561094, Fold 3 = 1.536986 (Mean = 1.7620, CV = 20.93%)
- **Window 10:** Fold 1 = 2.253370, Fold 2 = 1.853701, Fold 3 = 1.651971 (Mean = 1.9197, CV = 15.91%)

The promoted alpha_E = 1.690769 is remarkably stable and near-optimal across all historical training folds.

---

## E. Window Results
Pooled walk-forward out-of-sample performance (1,400 player rows / 277 team periods):

| Window | Pooled Player MAE | Delta vs AC_FE Base | Delta vs AC | Pooled Team MAE | Team Delta vs Base | Folds Improved |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Window 3** | 5.020290 | +0.012371 | -0.019369 | 21.955689 | +0.190430 | 1 / 3 |
| **Window 5 (Walk-Forward)** | 5.008584 | +0.000665 | -0.031075 | 21.768075 | +0.002816 | 0 / 3 |
| **Window 5 (Promoted Base)** | **5.007919** | **0.000000** | **-0.031740** | **21.765259** | **0.000000** | **Baseline** |
| **Window 8** | 5.019959 | +0.012040 | -0.019700 | 21.806075 | +0.040816 | 1 / 3 |
| **Window 10** | 5.013208 | +0.005289 | -0.026451 | 21.795410 | +0.030151 | 2 / 3 |

---

## F. Best Candidate vs AC_FE
- No candidate window (3, 8, 10) outperforms the promoted 5-game window.
- Within Window 5, the walk-forward expanding fit (MAE = 5.008584) matches the frozen promoted baseline (MAE = 5.007919) within 0.00066 points (0.01% numerical difference).
- Team MAE is also minimized at Window 5 (21.765259 vs 21.955689 for w=3, 21.806075 for w=8, 21.795410 for w=10).

---

## G. Fold Stability
- Window 3 regresses in Folds 1 and 2.
- Window 8 regresses in Folds 1 and 2.
- Window 10 regresses in Fold 2 (+0.0463 MAE).
- Promoted Window 5 provides the most balanced, robust historical performance.

---

## H. Mid-Tier High-Combat
- On pooled walk-forward `MID_TIER - HIGH_FE` matchups:
  - AC MAE: 5.1633
  - AC_FE Base MAE: 5.0301 (Delta = -0.1332)
  - AC Bias: -1.4116
  - AC_FE Base Bias: -1.0967 (Bias reduction = +0.3149 points)
- Window 5 preserves the maximal mid-tier undervaluation correction.

---

## I. Bootstrap
- 1,000 team-period resamples confirm that no alternative window has a >35% probability of improving player MAE over Window 5.
- Promoted AC_FE baseline parameter choices are robustly defended.

---

## J. 2026 Firewall
```text
2026 was not used for alpha fitting.
2026 was not used for window selection.
2026 was not used for candidate tie-breaking.
2026 candidate performance was not evaluated.
The 2026 tournament was not rerun.
```

---

## K. Tier-1 Decision
```text
RETAIN_PROMOTED_AC_FE
```
*(The promoted operational baseline AC_FE with alpha_E = 1.690769 and history_window = 5 remains the optimal Tier-1 configuration).*

---

## L. Candidate Status
Promoted AC_FE remains the authoritative operational baseline. No provisional candidate freeze is required.

---

## M. R6B Eligibility
- **Positive FE Gain vs AC (Window 5):** -0.0148 MAE (slight regression).
- **Negative FE Gain vs AC (Window 5):** +0.1031 MAE (major error reduction).
- **Asymmetry Hypothesis Supported:** `TRUE`. Decoupling positive combat opportunity boosts from negative combat penalties is strongly supported by pre-2026 evidence.

---

## N. Next Node
```text
PROCEED_TO_STAGE_10D_R6B_PRE2026_ASYMMETRIC_FE_RESPONSE_EVALUATION
```
