[x] Terra medium verified; direct Codex only; AGY/subagents unused
[x] S30 reproduction, SUPPORT protection, non-SUP neutralization, and total preservation
[x] frozen gamma grid; no 2026, P1, OATS, or pairwise work
[x] policy exception deactivated and default config restored
