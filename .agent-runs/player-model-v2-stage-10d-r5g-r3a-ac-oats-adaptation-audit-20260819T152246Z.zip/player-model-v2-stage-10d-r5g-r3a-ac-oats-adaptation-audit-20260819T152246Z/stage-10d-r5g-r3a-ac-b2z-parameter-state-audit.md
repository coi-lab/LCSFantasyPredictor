# Stage 10D-R5G-R3A: AC/B2Z Parameter vs State Audit

## 1. Frozen Parameters
- **Ridge L2 regularization:** 80.0 (fitted on 2020-2025 pre-2026 development data)
- **Allocation strength (gamma):** 0.40 (applied to neutralized non-support delta)
- **Neutralization rule:** `neutralize_non_support()`
  - SUP is protected: `delta_B(SUP) = 0.0`
  - Non-SUP roles (TOP, JGL, MID, BOT) are centered: `sum(delta_B across 4 roles) = 0.0`
- **Ridge Intercept:** Unpenalized intercept = -0.000094
- **Caps:** No artificial score caps or clipping applied in production formula

## 2. Frozen Ridge Model Weights (Trained on 2020-2025)

| Feature | Learned Weight | Interpretation |
|---|---|---|
| `role_BOT` | +0.487650 | Structural baseline allocation shift toward BOT |
| `role_SUP` | +0.374647 | Structural baseline (neutralized to 0 by SUP-protection rule) |
| `role_MID` | +0.292417 | Structural baseline allocation shift toward MID |
| `role_JGL` | -0.083571 | Structural baseline allocation shift away from JGL |
| `role_TOP` | -1.071142 | Structural baseline allocation shift strongly away from TOP |
| `s30_centered` | -0.545108 | Compresses extreme S30 within-team share differences |
| `prior_player_rating` | +0.061373 | Shifts share toward higher-Elo players |
| `prior_role_relative_rating` | +0.061373 | Shifts share toward role-dominant players |
| `core_BOT` | +0.077594 | Couples JGL and SUP to strong BOT carry |
| `core_MID` | +0.037416 | Couples JGL to strong MID carry |
| `prior_core_state` | -0.125520 | Regularizes high-variance core states |

## 3. Dynamic Feature Inputs in 2026
The 15 dynamic features in B2Z **all update chronologically before each 2026 lock**:
- `prior_player_rating`: updates after every series via pre-lock Elo
- `prior_core_state`: updates after every series via exponential decay
- `s30_centered`: updates via S30 240-day decay + matchup win conditioning
- `core_BOT` & `core_MID`: update dynamically as teammate core states evolve
- `matchup_strength_diff` & `predicted_team_win_probability`: update with each scheduled opponent

## 4. Adaptiveness Classification
- **Classification:** `PARTIALLY_CURRENT_SEASON_ADAPTIVE`
- **Rationale:** The feature inputs (ratings, core state, S30 base, matchup) advance dynamically with every completed 2026 series. However, the regression coefficients (e.g. role constants `role_TOP = -1.07`, `role_BOT = +0.49`) are frozen from 2020-2025.
