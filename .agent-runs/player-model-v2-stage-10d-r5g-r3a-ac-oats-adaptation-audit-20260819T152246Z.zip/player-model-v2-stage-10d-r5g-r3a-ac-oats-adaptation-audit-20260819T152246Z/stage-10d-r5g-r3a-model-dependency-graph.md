# Stage 10D-R5G-R3A: Model Dependency Graph

## 1. Executive Lineage Proof

### MODEL: S30 (Operational Baseline)
- **Base prediction:** T3_240d decay baseline prediction (`m0_prediction` combined with 240-day exponential decay)
- **Adjustment 1:** Player share correction (`historical_share_prior` blended with recent share)
- **Adjustment 2:** Win/loss probability conditioning from Stage 8 matchup model
- **Final formula:** `S30 = p_win * S30_win + (1 - p_win) * S30_loss`

---

### MODEL: S30_OATS (Research Challenger)
- **Base prediction:** `S30_prediction`
- **Adjustment 1:** Team-total residual Ridge regression (`delta_O_team = fit_predict(train, score, alpha=1.0)`)
- **Adjustment 2:** S30 share proportional allocation: `delta_O_player = delta_O_team * S30_share`
- **Final formula:** `S30_OATS = S30 + delta_O = (S30_team_total + delta_O_team) * S30_share`

---

### MODEL: AC (Pre-2026 Finalist)
- **Base prediction:** `S30_prediction`
- **Adjustment 1 (Allocation):** `delta_B = B2Z_NS_prediction - S30_prediction` (B2Z non-support zero-sum allocation)
- **Adjustment 2 (Team Strength):** `delta_O = S30_OATS_prediction - S30_prediction` (OATS team-strength adjustment)
- **Final formula:** `AC = S30 + delta_B + delta_O`
  - Equivalent formulation: `AC = S30_OATS + delta_B`
  - Equivalent formulation: `AC = B2Z_NS + delta_O`

#### Explicit Answer: Does AC include OATS?
**YES.**
`AC` already includes `delta_O = S30_OATS - S30`.
`AC = S30_OATS + delta_B`.
Therefore, adding OATS again to AC would double-count `delta_O`.

---

### MODEL: BC (Non-Finalist Sensitivity Comparator)
- **Base prediction:** `S30_prediction`
- **Adjustment 1 (Playstyle Allocation):** `delta_P = P1_prediction - S30_prediction` (P1 dynamic playstyle allocation)
- **Adjustment 2 (Team Strength):** `delta_O = S30_OATS_prediction - S30_prediction` (OATS team-strength adjustment)
- **Final formula:** `BC = S30 + delta_P + delta_O`
  - Equivalent formulation: `BC = S30_OATS + delta_P`
  - Equivalent formulation: `BC = P1 + delta_O`

#### Explicit Answer: Does BC include OATS?
**YES.**
`BC` already includes `delta_O = S30_OATS - S30`.
`BC = S30_OATS + delta_P`.

---

## 2. Algebraic Lineage Verification

| Model | Formula | S30 Component | Allocation Component | Team Strength Component |
|---|---|---|---|---|
| S30 | S30 | Base (1.0) | None (0.0) | None (0.0) |
| S30_OATS | S30 + delta_O | Base (1.0) | None (0.0) | delta_O (1.0) |
| AC | S30 + delta_B + delta_O | Base (1.0) | delta_B (B2Z-NS, 1.0) | delta_O (OATS, 1.0) |
| BC | S30 + delta_P + delta_O | Base (1.0) | delta_P (P1, 1.0) | delta_O (OATS, 1.0) |

- `delta_B = gamma * neutralized_non_sup_delta` (gamma = 0.40, L2 = 80.0, SUP = 0.0, non-SUP zero-sum)
- `delta_P = S30_team_total * P1_share - S30_prediction` (alpha = 0.70, window = 15, zero-sum)
- `delta_O = S30_OATS_prediction - S30_prediction` (K = 48, carryover = 0.75, alpha = 1.0)
