# Stage 10D-R5G-R3A: OATS Parameter vs State Audit

## 1. Frozen Parameters
- **K factor:** 48 (zero-sum Elo update per series)
- **Carryover:** 0.75 (shrinkage toward 1500 league mean at season/split transition: `R = 1500 + 0.75 * (R_prev - 1500)`)
- **Rating scale:** 400.0 (standard Elo logistic denominator)
- **Recent window:** 5 (number of recent series for schedule strength calculation)
- **Neutral reference rating:** 1500.0 (initialization for new teams without prior history)

## 2. Dynamic 2026 State
- OATS ratings update **chronologically after every completed series** in 2026.
- For each target round lock, OATS rating is derived **strictly from series completed before the lock timestamp**.
- Later 2026 locks (e.g. Lock-In R2 through R6, Spring R1 through R5) see all preceding completed series in 2026.

## 3. Concrete 2026 Team Rating Trajectories

| Team | Lock-In R1 | Lock-In R2 | Lock-In R3 | Lock-In R4 | Lock-In R5 | Spring R1 | Spring R5 |
|---|---|---|---|---|---|---|---|
| Sentinels | 1500.00 | 1471.26 | 1489.48 | 1514.96 | 1536.22 | 1513.72 | 1526.40 |
| FlyQuest | 1765.27 | 1703.37 | 1712.82 | 1683.50 | 1658.13 | 1629.74 | 1640.10 |
| Cloud9 | 1604.17 | 1619.12 | 1634.39 | 1663.71 | 1663.71 | 1641.38 | 1667.38 |
| Dignitas | 1351.16 | 1386.04 | 1367.82 | 1381.98 | 1381.98 | 1399.82 | 1410.20 |

## 4. Chronology & Leakage Audit
- `source_max_timestamp < target_cutoff`: **PASS (100% of rows)**
- `same_lock_updates_used = 0`: **PASS (100% of rows)**
- `future_violations = 0`: **PASS**

### Answers:
- **Does OATS update after completed 2026 series?** **YES.**
- **Does a later 2026 lock use updated 2026 results?** **YES.**
