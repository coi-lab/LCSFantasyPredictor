# Stage 10D-R5G-R3A: AC/OATS Implementation and Adaptation Audit

## VERDICT

```
STAGE_10D_R5G_R3A_AC_ALREADY_INCLUDES_OATS
```

---

## A. AC Formula

The exact mathematical implementation of AC in production is:

```text
AC = S30 + delta_B + delta_O
```
where:
- `S30`: S30 operational baseline player prediction
- `delta_B`: B2Z-NS non-support zero-sum allocation adjustment (`B2Z_NS_prediction - S30_prediction`)
- `delta_O`: OATS team strength adjustment (`S30_OATS_prediction - S30_prediction`)

Equivalent exact formulation:
```text
AC = S30_OATS + delta_B
```

---

## B. BC Formula

```text
BC = S30 + delta_P + delta_O = S30_OATS + delta_P
```
where `delta_P = P1_prediction - S30_prediction` (P1 dynamic playstyle adjustment).

---

## C. Is AC Already OATS + Allocation?

**YES.**
- `delta_O = S30_OATS - S30` is explicitly added into `AC`.
- Across all 637 player prediction rows in 2026, `AC = S30_OATS + delta_B` with max error **`0.00000000000000710543`** (exact floating precision).
- Creating a future arm `AC + OATS` would **DOUBLE-COUNT** OATS.

---

## D. How OATS Changes Through 2026

- **State updates:** Pre-lock team Elo ratings update after every completed series in 2026.
- **Cadence:** K=48 zero-sum update applied to both teams when a series completes.
- **Strict Chronology:** `source_max_timestamp < target_cutoff` holds for 100% of rows; 0 same-lock or future violations.
- **Later locks:** Later locks (Lock-In R2-R6, Spring R1-R5) see all preceding completed 2026 series.

---

## E. How AC/B2Z Changes Through 2026

- **Dynamic current-season features:** `prior_player_rating`, `prior_core_state`, `s30_centered`, `core_MID`, `core_BOT`, `prior_role_adjusted_kp`, `prior_effective_evidence`, `prior_residual_uncertainty` all update dynamically as 2026 series complete.
- **Dynamic matchup features:** `predicted_team_win_probability` and `matchup_strength_diff` update based on scheduled opponent.
- **Dynamic roster features:** `team_continuity` and role coupling update when starters change.
- **Static features:** One-hot role indicators and Ridge regression weights (L2=80.0, fitted on 2020-2025).

---

## F. Can AC Follow Emerging Team Role-Distribution Patterns?

**PARTIALLY.**
- If a team becomes more BOT-centric, BOT's `prior_core_state`, `prior_player_rating`, and `s30_centered` rise relative to teammates.
- The learned Ridge weights award positive share to higher-Elo and higher-core players, so BOT's allocated share increases.
- However, the global role prior (`role_TOP = -1.07`, `role_BOT = +0.49`) remains fixed from 2020-2025.

---

## G. State-Advancement Effect

- **Mean absolute effect of state advancement:** **`2.6112` pts**
- State advancement accounts for significant week-to-week prediction variation beyond static matchup shifts.

---

## H. Team Examples

- **Shopify Rebellion:** High role movement (2.73 range across roles) as JGL and BOT ratings shifted through 2026.
- **FlyQuest:** Smallest movement (1.49 range) due to high baseline consistency.
- **Sentinels:** Initialized at 1500.00 in Round 1; rose to 1536.22 by Lock-In R5 and 1526.40 by Spring R5.
- **Cloud9:** Maintained strong 1604 -> 1667 Elo rating throughout the season.

---

## I. Does AC Preserve Team Total?

**YES.**
- `sum(delta_B across all 5 roles) = 0.00000000000000` (max difference `0.0000000000000000`).
- `AC team total` exactly equals `S30_OATS team total` for 100% of team-periods.

---

## J. Is "OATS + AC" a Valid New Arm?

**NO — WOULD DOUBLE COUNT OATS.**
`AC` is already `S30 + delta_B + delta_O = S30_OATS + delta_B`.

---

## K. What Needs Fixing Before Schedule-Adjusted Form?

- None in the combination logic: AC correctly integrates OATS and B2Z-NS.
- The pipeline is sound and ready for Stage 10D-R4A schedule-adjusted form design.

---

## L. Next Node

```text
PROCEED_TO_STAGE_10D_R5G_R4A_SCHEDULE_ADJUSTED_FORM_DESIGN
```

---

## M. Freeze Status

```text
S30 remains unchanged.
S30_OATS remains unchanged.
AC remains unchanged.
BC remains unchanged.
T3_240d remains unchanged.
No model was fit or tuned.
No 2026 tuning was performed.
No tournament result was changed.
No candidate was promoted or archived.
```
