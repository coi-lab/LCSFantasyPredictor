# Stage 10D-R5G-R3A: Deterministic Team Case Studies

## Team: Shopify Rebellion (`oe:team:da1143bf9a245b78a8dc86417de85b3`)
**Selection Criterion:** `LARGEST_ROLE_ALLOCATION_MOVEMENT`

| Round | Opponent | Prelock OATS Rating | Win Prob | TOP delta_B | JGL delta_B | MID delta_B | BOT delta_B | SUP delta_B | Sum delta_B |
|---|---|---|---|---|---|---|---|---|---|
| Lock-In Round 1 | Opponent | 1432.9 | 0.691 | +0.27 | -0.26 | -0.02 | +0.02 | +0.00 | -0.0000 |
| Lock-In Round 2 | Opponent | 1486.6 | 0.375 | +0.33 | -0.54 | +0.35 | -0.14 | +0.00 | +0.0000 |
| Lock-In Round 3 | Opponent | 1471.3 | 0.634 | +0.45 | -0.56 | +0.28 | -0.18 | +0.00 | -0.0000 |
| Lock-In Round 5 | Opponent | 1445.8 | 0.490 | +0.37 | -0.49 | +0.25 | -0.13 | +0.00 | +0.0000 |
| Lock-In Round 6 | Opponent | 1482.9 | 0.461 | +0.35 | -0.35 | +0.14 | -0.14 | +0.00 | -0.0000 |
| Spring Round 1 | Opponent | 1569.4 | 0.428 | +0.29 | -0.20 | +0.11 | -0.20 | +0.00 | +0.0000 |
| Spring Round 2 | Opponent | 1533.1 | 0.669 | +0.47 | -0.30 | +0.06 | -0.23 | +0.00 | +0.0000 |
| Spring Round 3 | Opponent | 1547.8 | 0.681 | +0.43 | -0.29 | +0.12 | -0.25 | +0.00 | -0.0000 |
| Spring Round 4 | Opponent | 1566.6 | 0.702 | +0.43 | -0.23 | +0.10 | -0.30 | +0.00 | +0.0000 |
| Spring Round 5 | Opponent | 1582.6 | 0.579 | +0.36 | -0.21 | +0.06 | -0.20 | +0.00 | +0.0000 |

**Analysis:**
- **Why did the model change?** Zero-sum allocation `delta_B` shifted week-to-week based on teammate performance deltas and opponent strength.
- **Preservation verified:** Sum of `delta_B` across all 5 slots is exactly 0.0000 in every round.

---

## Team: FlyQuest (`oe:team:2e66da41dc460dd378e3bcc57042d31`)
**Selection Criterion:** `SMALLEST_ROLE_ALLOCATION_MOVEMENT_AND_STRONG_TEAM`

| Round | Opponent | Prelock OATS Rating | Win Prob | TOP delta_B | JGL delta_B | MID delta_B | BOT delta_B | SUP delta_B | Sum delta_B |
|---|---|---|---|---|---|---|---|---|---|
| Lock-In Round 1 | Opponent | 1765.3 | 0.484 | +0.13 | +0.21 | -0.21 | -0.13 | +0.00 | +0.0000 |
| Lock-In Round 2 | Opponent | 1703.4 | 0.570 | +0.07 | -0.01 | +0.01 | -0.07 | +0.00 | -0.0000 |
| Lock-In Round 3 | Opponent | 1712.8 | 0.582 | +0.02 | +0.03 | -0.03 | -0.02 | +0.00 | +0.0000 |
| Lock-In Round 4 | Opponent | 1683.5 | 0.474 | -0.15 | +0.09 | +0.12 | -0.07 | +0.00 | +0.0000 |
| Lock-In Round 5 | Opponent | 1658.1 | 0.510 | -0.16 | +0.22 | -0.02 | -0.05 | +0.00 | +0.0000 |
| Spring Round 1 | Opponent | 1621.1 | 0.433 | -0.29 | +0.24 | +0.01 | +0.04 | +0.00 | -0.0000 |
| Spring Round 2 | Opponent | 1560.5 | 0.471 | -0.23 | +0.18 | +0.04 | +0.01 | +0.00 | -0.0000 |
| Spring Round 3 | Opponent | 1578.9 | 0.473 | -0.23 | +0.13 | +0.09 | +0.02 | +0.00 | -0.0000 |
| Spring Round 4 | Opponent | 1546.8 | 0.590 | +0.04 | +0.16 | -0.17 | -0.03 | +0.00 | -0.0000 |
| Spring Round 5 | Opponent | 1559.3 | 0.632 | +0.08 | +0.08 | -0.15 | -0.01 | +0.00 | -0.0000 |

**Analysis:**
- **Why did the model change?** Zero-sum allocation `delta_B` shifted week-to-week based on teammate performance deltas and opponent strength.
- **Preservation verified:** Sum of `delta_B` across all 5 slots is exactly 0.0000 in every round.

---

## Team: Sentinels (`oe:team:f90422f1cbcb24bc2a855202582ec29`)
**Selection Criterion:** `NEW_2026_TEAM_ROSTER_TRANSFER`

| Round | Opponent | Prelock OATS Rating | Win Prob | TOP delta_B | JGL delta_B | MID delta_B | BOT delta_B | SUP delta_B | Sum delta_B |
|---|---|---|---|---|---|---|---|---|---|
| Lock-In Round 1 | Opponent | 1500.0 | 0.566 | -0.04 | -0.09 | +0.03 | +0.10 | +0.00 | +0.0000 |
| Lock-In Round 2 | Opponent | 1471.3 | 0.572 | -0.29 | +0.09 | +0.27 | -0.07 | +0.00 | +0.0000 |
| Lock-In Round 3 | Opponent | 1489.5 | 0.558 | -0.08 | -0.03 | +0.20 | -0.09 | +0.00 | +0.0000 |
| Lock-In Round 4 | Opponent | 1515.0 | 0.541 | -0.01 | -0.09 | +0.22 | -0.11 | +0.00 | +0.0000 |
| Lock-In Round 5 | Opponent | 1536.2 | 0.429 | -0.01 | -0.11 | +0.10 | +0.02 | +0.00 | -0.0000 |
| Lock-In Round 6 | Opponent | 1522.1 | 0.482 | -0.03 | -0.04 | -0.03 | +0.09 | +0.00 | +0.0000 |
| Spring Round 1 | Opponent | 1497.3 | 0.590 | +0.10 | -0.16 | -0.07 | +0.12 | +0.00 | +0.0000 |
| Spring Round 2 | Opponent | 1470.7 | 0.375 | +0.00 | -0.17 | -0.08 | +0.24 | +0.00 | +0.0000 |
| Spring Round 3 | Opponent | 1457.8 | 0.527 | +0.04 | -0.12 | -0.11 | +0.19 | +0.00 | +0.0000 |
| Spring Round 4 | Opponent | 1489.9 | 0.485 | +0.04 | -0.13 | -0.08 | +0.17 | +0.00 | +0.0000 |
| Spring Round 5 | Opponent | 1470.8 | 0.421 | +0.01 | -0.15 | -0.00 | +0.14 | +0.00 | -0.0000 |

**Analysis:**
- **Why did the model change?** Zero-sum allocation `delta_B` shifted week-to-week based on teammate performance deltas and opponent strength.
- **Preservation verified:** Sum of `delta_B` across all 5 slots is exactly 0.0000 in every round.

---

## Team: Cloud9 (`oe:team:fc8e90107dabb9a35c490b0d86adea0`)
**Selection Criterion:** `TOP_CONTENDER_STRONG_BASELINE`

| Round | Opponent | Prelock OATS Rating | Win Prob | TOP delta_B | JGL delta_B | MID delta_B | BOT delta_B | SUP delta_B | Sum delta_B |
|---|---|---|---|---|---|---|---|---|---|
| Lock-In Round 1 | Opponent | 1604.2 | 0.740 | +0.15 | -0.05 | -0.01 | -0.09 | +0.00 | +0.0000 |
| Lock-In Round 2 | Opponent | 1619.1 | 0.625 | +0.15 | -0.11 | +0.01 | -0.04 | +0.00 | -0.0000 |
| Lock-In Round 3 | Opponent | 1634.4 | 0.418 | +0.12 | -0.10 | +0.14 | -0.16 | +0.00 | +0.0000 |
| Lock-In Round 4 | Opponent | 1663.7 | 0.526 | +0.19 | -0.14 | +0.02 | -0.07 | +0.00 | +0.0000 |
| Lock-In Round 5 | Opponent | 1689.1 | 0.571 | +0.19 | -0.13 | +0.01 | -0.07 | +0.00 | +0.0000 |
| Lock-In Round 6 | Opponent | 1703.2 | 0.621 | +0.22 | -0.10 | -0.01 | -0.11 | +0.00 | +0.0000 |
| Spring Round 1 | Opponent | 1668.3 | 0.572 | +0.11 | -0.01 | +0.05 | -0.15 | +0.00 | +0.0000 |
| Spring Round 2 | Opponent | 1645.2 | 0.625 | +0.08 | +0.03 | +0.05 | -0.16 | +0.00 | -0.0000 |
| Spring Round 3 | Opponent | 1658.1 | 0.729 | +0.13 | +0.02 | +0.02 | -0.17 | +0.00 | -0.0000 |
| Spring Round 4 | Opponent | 1669.6 | 0.746 | +0.12 | -0.02 | +0.07 | -0.17 | +0.00 | -0.0000 |
| Spring Round 5 | Opponent | 1680.3 | 0.764 | +0.06 | -0.01 | +0.13 | -0.19 | +0.00 | -0.0000 |

**Analysis:**
- **Why did the model change?** Zero-sum allocation `delta_B` shifted week-to-week based on teammate performance deltas and opponent strength.
- **Preservation verified:** Sum of `delta_B` across all 5 slots is exactly 0.0000 in every round.

---

## Team: Dignitas (`oe:team:0dbb780176ecad18f17292d1f5653af`)
**Selection Criterion:** `HIGH_MOVEMENT_DEVELOPING_ROSTER`

| Round | Opponent | Prelock OATS Rating | Win Prob | TOP delta_B | JGL delta_B | MID delta_B | BOT delta_B | SUP delta_B | Sum delta_B |
|---|---|---|---|---|---|---|---|---|---|
| Lock-In Round 1 | Opponent | 1351.2 | 0.309 | -0.02 | +0.05 | +0.01 | -0.04 | +0.00 | -0.0000 |
| Lock-In Round 2 | Opponent | 1386.0 | 0.428 | -0.10 | +0.12 | +0.06 | -0.07 | +0.00 | +0.0000 |
| Lock-In Round 3 | Opponent | 1367.8 | 0.511 | -0.40 | +0.08 | -0.20 | +0.53 | +0.00 | +0.0000 |
| Spring Round 1 | Opponent | 1382.0 | 0.625 | -0.04 | +0.24 | -0.02 | -0.18 | +0.00 | +0.0000 |
| Spring Round 2 | Opponent | 1391.6 | 0.331 | -0.27 | +0.32 | +0.09 | -0.14 | +0.00 | -0.0000 |
| Spring Round 3 | Opponent | 1376.9 | 0.307 | -0.25 | +0.29 | +0.13 | -0.17 | +0.00 | -0.0000 |
| Spring Round 4 | Opponent | 1363.9 | 0.410 | -0.20 | +0.30 | +0.20 | -0.31 | +0.00 | +0.0000 |
| Spring Round 5 | Opponent | 1351.5 | 0.236 | -0.16 | +0.23 | +0.16 | -0.24 | +0.00 | +0.0000 |

**Analysis:**
- **Why did the model change?** Zero-sum allocation `delta_B` shifted week-to-week based on teammate performance deltas and opponent strength.
- **Preservation verified:** Sum of `delta_B` across all 5 slots is exactly 0.0000 in every round.

---

