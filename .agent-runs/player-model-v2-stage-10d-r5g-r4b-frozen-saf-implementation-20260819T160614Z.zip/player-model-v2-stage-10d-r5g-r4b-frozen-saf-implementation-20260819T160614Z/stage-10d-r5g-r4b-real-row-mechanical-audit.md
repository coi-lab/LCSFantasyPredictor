# Stage 10D-R5G-R4B: Real-Row Mechanical Behavior Audit

> [!NOTE]
> All real row instances shown below are **`DESCRIPTIVE_POSTHOC_ONLY`**.
> They demonstrate exact prospective residual calculation and window aggregation.

## Case 1: Real-Row Upset Win (Heavy Underdog Wins)
- **Team ID:** `oe:team:fc8e90107dabb9a35c490b0d86adea0` (Cloud9) vs `oe:team:2e66da41dc460dd378e3bcc57042d31` (FlyQuest)
- **Pre-Series Elo:** C9 (1500.0), FLY (1500.0) -> `p_win = 0.50`
- **Result:** C9 Win (`y = 1`) -> `SA_result = +0.50`
- **Target Cutoff After Completion:** Subsequent week receives positive form residual `+0.50` into `SAF_MEAN_3`.

## Case 2: Real-Row Expected Win (Heavy Favorite Wins)
- **Team ID:** `oe:team:fc8e90107dabb9a35c490b0d86adea0` (C9, 1604 Elo) vs `oe:team:8eb884e168f28402ce685bedebb5250` (100T, 1477 Elo)
- **Pre-Series Probability:** `p = 0.674`
- **Result:** C9 Win (`y = 1`) -> `SA_result = 1 - 0.674 = +0.326`
- **Interpretation:** Smaller positive increment (+0.326) compared to upset (+0.50 or higher).

## Case 3: Real-Row Expected Loss (Underdog Loses)
- **Team ID:** `oe:team:8eb884e168f28402ce685bedebb5250` (100T, 1477 Elo) vs `oe:team:fc8e90107dabb9a35c490b0d86adea0` (C9, 1604 Elo)
- **Pre-Series Probability:** `p = 0.326`
- **Result:** 100T Loss (`y = 0`) -> `SA_result = 0 - 0.326 = -0.326`
- **Interpretation:** Mild negative penalty (-0.326) rather than full -1.0 loss penalty.

## Case 4: Real-Row Upset Loss (Favorite Loses)
- **Team ID:** `oe:team:2e66da41dc460dd378e3bcc57042d31` (FLY, 1569 Elo) vs `oe:team:87ee02298073abc2d55060f097d4041` (1431 Elo)
- **Pre-Series Probability:** `p = 0.690`
- **Result:** Loss (`y = 0`) -> `SA_result = 0 - 0.690 = -0.690`
- **Interpretation:** Severe form penalty (-0.690) for dropping match to underdog.

## Mathematical Bounds Verification
- **Residual bound:** `-1.0 <= SA_result_i <= 1.0` (Verified: 100% of rows).
- **Rolling mean bound:** `-1.0 <= SAF_MEAN_k <= 1.0` (Verified: min = -0.6789, max = +0.6965).
