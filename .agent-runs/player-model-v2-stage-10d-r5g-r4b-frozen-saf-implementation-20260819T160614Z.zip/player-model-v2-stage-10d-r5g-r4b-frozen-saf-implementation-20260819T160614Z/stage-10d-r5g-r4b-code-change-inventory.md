# Stage 10D-R5G-R4B: Code Change Inventory

| File | Change Purpose | Parent Behavior Impact | New Behavior |
|---|---|---|---|
| `fantasy_prediction/schedule_adjusted_form.py` | Implementation of prospective pre-lock SAF state builder, raw residual calculation, candidate aggregations (SAF_MEAN_3, SAF_MEAN_5), and explicit-scale integration interface | **NONE.** Parent models (S30, S30_OATS, AC, BC) are untouched and retain exact numerical parity. | Exposes `build_prelock_saf_state`, `calculate_saf_residual`, `calculate_saf_mean`, and `apply_saf_team_correction`. |
| `tests/test_stage10d_r5g_r4b_frozen_saf.py` | Unit test suite covering all 21 structural, accounting, temporal, and governance invariants. | **NONE.** Read-only test verification. | 21 passing unit tests. |
