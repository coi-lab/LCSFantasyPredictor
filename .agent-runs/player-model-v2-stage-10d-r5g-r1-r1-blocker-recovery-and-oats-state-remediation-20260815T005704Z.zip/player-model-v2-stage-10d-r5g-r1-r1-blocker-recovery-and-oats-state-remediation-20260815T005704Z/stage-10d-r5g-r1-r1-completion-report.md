BLOCKED_BY_RECOVERY_AUTHORITY_MISMATCH

Fact 6 failed: an original R5G diagnostic run contains 2026 player metrics, role metrics, lineups, and round results. Phase B was not started.
