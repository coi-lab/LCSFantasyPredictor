[x] directory-only evidence discovery
[x] no old evidence rewritten
[x] stopped at contradictory Fact 6 before Phase B
