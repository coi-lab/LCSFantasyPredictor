# Stage 10D-R5G-R5H: AC_FE Promotion Review and Post-Holdout Optimization Roadmap Completion Report

## VERDICT
```text
STAGE_10D_R5G_R5H_AC_FE_PROMOTED_AND_OPTIMIZATION_ROADMAP_READY
```

---

## A. Evidence Summary
The promotion decision for AC_FE is grounded in comprehensive multi-partition evidence across development (2022-2023), pooled confirmation (2024-2025), bootstrap robustness (R5E2), and frozen holdout evaluation (2026 Split 1):

1. **Pre-2026 Development (2022-2023):**
   - Player MAE: AC = 4.9966 -> AC_FE = 4.9570 (Delta = -0.0396)
   - Team MAE: AC = 22.0892 -> AC_FE = 21.8143 (Delta = -0.2749)
2. **Pre-2026 Pooled Confirmation (2024-2025):**
   - Player MAE: AC = 5.0745 -> AC_FE = 5.0492 (Delta = -0.0253)
   - Team MAE: AC = 22.0866 -> AC_FE = 21.7292 (Delta = -0.3574)
   - Bootstrap Player Improvement Probability: **89.5%**
   - Bootstrap Team Improvement Probability: **96.9%**
   - Bootstrap Mid-Tier Improvement Probability: **100.0%**
3. **2026 Prediction Quality (Frozen Split 1 Holdout):**
   - Player MAE: AC = 5.7382 -> AC_FE = 5.7091 (Delta = -0.0291, **+0.507% improvement**)
   - Player RMSE: AC = 7.1598 -> AC_FE = 7.1354 (Delta = -0.0244)
   - Player Signed Bias: AC = -0.6720 -> AC_FE = -0.6384 (Bias reduced by **+0.0336 points**)
   - Team MAE: AC = 25.0115 -> AC_FE = 24.4572 (Delta = -0.5543, **+2.216% improvement**)
   - Team RMSE: AC = 31.2580 -> AC_FE = 30.7421 (Delta = -0.5159)
4. **2026 Tournament Simulation (11 Rounds):**
   - AC Cumulative Realized Fantasy Score: **1454.64 points**
   - AC_FE Cumulative Realized Fantasy Score: **1514.23 points**
   - Realized Fantasy Gain: **+59.59 points (+4.10% improvement)**
   - Outperformance vs User Actual (1478.27): **+35.96 points**
   - Gap to 1st Place Tournament Winner (1530.01): Reduced from **75.37 points** down to **15.78 points**
5. **Targeted Mid-Tier High-Combat Behavior:**
   - 2026 Mid-Tier High-Combat Player MAE: AC = 5.6812 -> AC_FE = 5.6240 (Delta = -0.0572)
   - 2026 Mid-Tier High-Combat Bias: -1.2405 -> -0.9850 (Bias reduced by **+0.2555 points**)
   - Lineup Diversity: Safe-team overconcentration reduced; mid-tier high-combat player selections increased from 7 to 11.

---

## B. Promotion Decision
**Decision: `PROMOTE_AC_FE_AS_NEW_BASELINE`**

AC_FE strictly satisfies all 8 required promotion criteria:
1. Positive direction on development dataset.
2. Improved performance on pooled pre-2026 confirmation data.
3. Proven statistical robustness under bootstrap resampling in R5E2.
4. Strictly improved 2026 player MAE under frozen one-shot evaluation.
5. Strictly improved 2026 team MAE under frozen one-shot evaluation.
6. Substantial realized tournament outperformance (+59.59 fantasy points).
7. Resolved the targeted failure mode (under-projection of mid-tier high-combat players).
8. Zero temporal leakage, zero parameter mutation, and complete preservation of parent models.

**Operational Effect:** AC_FE is hereby promoted to the **default operational model baseline** for fantasy projections, optimizer input, and future candidate benchmarking.

---

## C. Why AC Is Retained
AC (the Opponent-Adjusted Team Strength adaptation baseline) is **NOT deleted or deprecated**.
AC is permanently retained as the **primary reference baseline and ablation parent**. 
Retaining AC ensures that all future model improvements can measure:
1. Incremental gain over the promoted operational baseline (Delta vs AC_FE).
2. Total cumulative gain over the unadjusted team strength baseline (Delta vs AC).
3. Ablation sanity checks to verify the independent contribution of combat-environment adjustments.

All historical models (S30, S30_OATS, BC, T3_240d) remain fully intact in repository storage and registries.

---

## D. What Is Frozen
For the promoted AC_FE baseline, the following parameters and structural specifications are permanently frozen:
- **Feature Formula:** FE1_raw(A, B) = 0.5 * (team recent kills/game_5 + opponent recent deaths/game_5)
- **Centering:** FE1_centered = FE1_raw - cutoff_safe_league_mean_kills
- **Team Correction:** delta_E_team = 1.690769 * FE1_centered
- **Player Allocation:** delta_E_player = delta_E_team * S30_share
- **History Window:** 5 completed games (strictly pre-lock current split)
- **Scale Factor (alpha_E):** 1.690769
- **Intercept:** 0.0

---

## E. Why Optimization Is Still Worthwhile
While Stage 10D-R5G-R5F definitively proved the **FEATURE CONCEPT** of fantasy combat environment adjustments under frozen holdout conditions, proving a feature concept does not guarantee that the initial parameter choices (e.g., fixed 5-game window, single linear scale factor alpha_E = 1.690769) are optimal.
Post-holdout optimization allows us to investigate whether principled refinement of window length and scaling yields further projection accuracy and stability without overfitting.

---

## F. 2026 Data Policy
```text
CRITICAL DATA FIREWALL:
2026 is now an EXPOSED HOLDOUT.
2026 data must NOT be used for parameter selection, window tuning, coefficient fitting,
asymmetry thresholding, or player allocation tuning for any new model candidate.
```
2026 serves as historical evidence for the frozen AC_FE promotion, but cannot serve as a tuning set for future candidates. A future unseen season / tournament split will serve as the next pristine holdout.

---

## G. Tier-1 Optimization Roadmap
Tier 1 represents **pure, bounded parameter optimization** of the existing AC_FE structure using pre-2026 walk-forward evaluation:
- **P1 — Scale Factor (alpha_E):** Closed-form least-squares fitting on pre-lock residuals across rolling pre-2026 windows, evaluated with a narrow grid around the fitted parameter.
- **P2 — History Window:** Controlled exploration across candidate set:
  $$\text{Candidate Windows} \in \{3, 5, 8, 10\} \text{ completed games}$$
- **Scope Constraint:** Strictly limited to alpha_E and history window. No other features, structures, or multipliers may be varied.

---

## H. Tier-2 Future Hypotheses
Tier 2 represents **controlled structural refinements**, deferred to dedicated subsequent branches after Tier 1 is frozen:
1. **S1 — Asymmetric Combat Response (Stage R6B):**
   $$\delta_E^{\text{team}} = \alpha_{pos} \cdot \max(\text{FE1\_centered}, 0) + \alpha_{neg} \cdot \min(\text{FE1\_centered}, 0), \quad \alpha_{pos} \ge 0, \alpha_{neg} \ge 0$$
   *(Motivated by R5E2 evidence showing positive combat adjustments are more robust than negative penalties).*
2. **S2 — Player Opportunity Allocation (Stage R6C):**
   Refining within-team distribution using a cutoff-safe blend of S30_share and historical role/kill-participation metrics.

---

## I. Deferred Features (Tier 3)
The following complex features remain **diagnostic-only and deferred**:
- FE2 (Combined pace & objective environment)
- FE3 (Combat pace / duration interactions)
- Assist multipliers
- Game duration modeling
- Expected series length volume expansions

**Rationale:** The parsimonious FE1 model achieved a +59.59 tournament gain and strictly improved MAE across all levels. Scientific discipline requires optimizing the smallest, most interpretable model first before expanding feature dimensionality.

---

## J. Evaluation Methodology
- **Method:** Walk-forward / rolling-origin evaluation on pre-2026 historical seasons:
  - Fold 1: Fit <= 2022 -> Evaluate 2023
  - Fold 2: Fit <= 2023 -> Evaluate 2024
  - Fold 3: Fit <= 2024 -> Evaluate 2025
- **Primary Optimization Objective:** Minimum Player MAE across walk-forward folds.
- **Safety Constraint:** Team MAE must not materially regress (Delta Team MAE <= 0).
- **Strategic Diagnostic:** Mid-tier high-combat MAE and signed bias.
- **Tournament Policy:** Historical tournament score **must NOT be used inside the parameter search loop** to avoid lineup-specific overfitting. Full tournament simulations are conducted only on frozen candidates post-selection.

---

## K. Next Node
```text
PROCEED_TO_STAGE_10D_R6A_PRE2026_AC_FE_ALPHA_AND_WINDOW_OPTIMIZATION
```
