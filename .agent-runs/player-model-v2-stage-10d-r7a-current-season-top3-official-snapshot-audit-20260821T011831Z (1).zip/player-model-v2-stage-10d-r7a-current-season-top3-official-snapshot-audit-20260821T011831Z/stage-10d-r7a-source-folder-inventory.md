# Stage 10D-R7A Source Folder Inventory

## Source Folder
- **Path**: `LCSFantasyImages/Rayz results/`
- **Scope**: Four most recent weeks of 2026 LCS season (2026 Split 3 Rounds 1 to 4).

## Folder Contents
- `Week1/`: `week1_1.png`, `week1_2.png`, `week1_3.png`, `Week1Roster.png`, `QuidLocke.png`
- `Week2/`: `MattyMcDaddy.png`, `New Horizon.png`, `cgempathy.png`, `asdfg.png`, `Week2Results.png`
- `Week3/`: `Pallibear.png`, `Kronos.png`, `Epic.png`, `Week3Results.png`
- `Week4/`: `FireChicken.png`, `ZOFGK.png`, `kitzElite.png`, `Week4Results.png`

## Archived Official API Snapshots (`data/raw/official_market_snapshots/`)
- `round-1-split-3_20260724T131915Z.csv` / `.json` (Round 1 lock)
- `round-2-split-3_20260728T150935Z.csv` / `.json` (Round 2 lock)
- `round-3-split-3_20260807T145636Z.csv` / `.json` (Round 3 lock)
- `round-4-split-3_20260813T022316Z.csv` / `.json` (Round 4 lock)

## Status
All 4 weeks uniquely resolved without ambiguity.
