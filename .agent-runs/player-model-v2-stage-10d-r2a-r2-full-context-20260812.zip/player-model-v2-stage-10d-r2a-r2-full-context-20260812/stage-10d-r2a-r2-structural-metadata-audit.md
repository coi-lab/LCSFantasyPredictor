# Structural metadata safety audit

`team`, `opponent`, match date, patch and series identity are structural target-match metadata under the R2 convention. GoL score, winner, realized game count, duration, KDA, gold, damage, picks, bans and champion selections were not parsed or used. BO is deliberately null because it cannot be extracted without result-dependent score parsing in the cached pages. No betting or odds page was accessed.
