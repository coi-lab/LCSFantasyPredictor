# BLOCKED_BY_B0_REPRODUCTION

R3B froze a 6,079-row Stage 3E full population (1,044 rows in 2020, 1,063 in 2021, and 3,972 in 2022-2026), while every actual S30 authority is limited to the latter 3,972 rows. No authoritative frozen exact unchanged warmup S30 artifact exists for the missing 2,107 rows. The tracked T3 artifacts begin in 2022; the only tracked S30 export is 2026, and Stage 9D/9E only reproduce available post-warmup S30. Per the hard B0 gate, B1 was not fit.
