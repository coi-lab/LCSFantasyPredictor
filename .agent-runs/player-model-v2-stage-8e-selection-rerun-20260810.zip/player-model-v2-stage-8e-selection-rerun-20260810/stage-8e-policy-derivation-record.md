# Policy derivation

This policy uses the original Stage 8E prompt, before the diagnostic metrics:

- MAE guardrail: candidate MAE must be at most 1.005 times T3 MAE.
- Ranking/tail: at least two of Top-10 recall, Top-20 recall, Spearman, and
  Bottom-20 identification must strictly improve.
- Dispersion: SD ratio must move closer to 1.0 without failing ranking.
- Winner/loser and matchup differential: must not materially worsen. The
  available pre-existing team-total differential proxy is required not to
  worsen.

No diagnostic H-candidate metric informed a threshold or tie-break. A passing
candidate must pass every gate; ties retain the simpler T3 checkpoint.
