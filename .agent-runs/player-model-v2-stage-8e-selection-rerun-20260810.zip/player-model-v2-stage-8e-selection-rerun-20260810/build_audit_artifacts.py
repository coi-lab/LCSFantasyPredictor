"""Build non-model audit views from the frozen Stage 8E evaluator outputs."""
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).parent
shared = pd.read_csv(ROOT / "stage-8e-shared-lock-audit.csv")
shared.to_csv(
    ROOT / "stage-8e-canonical-series-schedule.csv",
    index=False,
)

lock = (
    shared.groupby(["prediction_period_id", "team_a_cutoff"], as_index=False)
    .agg(
        series_count=("series_id", "count"),
        all_same_cutoff=("same_cutoff", "all"),
        max_probability_sum_deviation=("probability_sum", lambda values: (values - 1).abs().max()),
        latest_eligible_history=("eligible_history_max_timestamp", "max"),
    )
    .rename(columns={"team_a_cutoff": "lock_cutoff"})
)
lock["no_future_history"] = lock["latest_eligible_history"] < lock["lock_cutoff"]
lock["pass"] = lock["all_same_cutoff"] & lock["no_future_history"] & (lock["max_probability_sum_deviation"] < 1e-12)
lock.to_csv(ROOT / "stage-8e-same-lock-leakage-audit.csv", index=False)

locks = lock.sort_values("lock_cutoff").reset_index(drop=True)
rolling = pd.DataFrame(
    {
        "previous_lock": locks["lock_cutoff"].shift(1),
        "next_lock": locks["lock_cutoff"],
        "previous_lock_series_count": locks["series_count"].shift(1),
        "next_lock_series_count": locks["series_count"],
        "state_update_rule": "historical player scores strictly earlier than next_lock",
        "pass": locks["pass"],
    }
).dropna()
rolling.to_csv(ROOT / "stage-8e-rolling-state-update-audit.csv", index=False)

pd.DataFrame(
    [
        {
            "status": "NOT_EVALUATED",
            "reason": "Frozen Stage 8E candidates predict player scores; they do not emit a series-outcome target needed for favorite/underdog calibration.",
        }
    ]
).to_csv(ROOT / "stage-8e-favorite-underdog-calibration.csv", index=False)

pd.DataFrame(
    [
        {
            "status": "NOT_EVALUATED",
            "reason": "The frozen evaluator result schema intentionally has no role field; no post-hoc role inference was introduced during the clean rerun.",
        }
    ]
).to_csv(ROOT / "stage-8e-role-results.csv", index=False)
