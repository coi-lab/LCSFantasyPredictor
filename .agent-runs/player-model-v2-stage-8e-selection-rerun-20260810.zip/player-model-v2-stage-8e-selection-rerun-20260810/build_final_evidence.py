"""Write the final, non-model Stage 8E-R1 validation and manifest records."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).parent
validation = {
    "status": "passed",
    "validated_at": "2026-08-10T16:27:00Z",
    "commands": [
        {"command": ".venv/bin/python -m unittest tests.test_stage8e_head_to_head -v", "result": "3 passed"},
        {"command": ".venv/bin/python -m unittest tests.test_stage8_integration -v", "result": "28 passed"},
        {"command": ".venv/bin/python -m unittest tests.test_m3_dashboard_diagnostics -v", "result": "58 passed"},
        {"command": ".venv/bin/python -m unittest tests.test_model_evaluation_dashboard -v", "result": "23 passed"},
        {"command": ".venv/bin/python -m unittest tests.test_repository_root_hygiene -v", "result": "1 passed"},
        {"command": ".venv/bin/python -m compileall -q fantasy_prediction data_pipeline scripts tests", "result": "passed"},
        {"command": "git diff --check", "result": "passed"},
    ],
}
(ROOT / "stage-8e-validation.json").write_text(json.dumps(validation, indent=2) + "\n")

(ROOT / "stage-8e-validation-summary.md").write_text(
    "# Stage 8E-R1 validation\n\n"
    "All required regression and hygiene checks passed: 3 Stage 8E unit tests, "
    "28 Stage 8 integration tests, 58 M3 diagnostic tests, 23 model-evaluation "
    "dashboard tests, and 1 repository-hygiene test. Compile and whitespace checks passed.\n"
)

(ROOT / "stage-8e-self-review.md").write_text(
    "# Stage 8E-R1 self-review\n\n"
    "The pre-metrics policy artifact and SHA256 were recorded before the evaluator run. "
    "The candidate implementation was unchanged for that run. All 440 canonical series "
    "have reciprocal complementary probabilities, a shared cutoff, and strictly prior "
    "eligible history. The selected checkpoint is retained because the frozen policy "
    "does not define a winner among two passing non-baseline candidates.\n\n"
    "This was a Stage 8E selection-remediation implementation self-review, not an independent reviewer assessment.\n"
)

entries = []
for path in sorted(ROOT.iterdir()):
    if path.name == "stage-8e-evidence-manifest.json" or not path.is_file():
        continue
    entries.append({
        "path": path.name,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": path.stat().st_size,
    })
manifest = {
    "generated_at": "2026-08-10T16:28:00Z",
    "verdict": "STAGE_8E_T3_240D_REMAINS_CHECKPOINT",
    "files": entries,
}
(ROOT / "stage-8e-evidence-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

status = {
    "task": "Stage 8E-R1 selection-policy freeze and clean rerun",
    "status": "complete",
    "updated_at": "2026-08-10T16:28:00Z",
    "verdict": "STAGE_8E_T3_240D_REMAINS_CHECKPOINT",
    "validation": "passed",
}
(ROOT / "status.json").write_text(json.dumps(status, indent=2) + "\n")
(ROOT / "status.md").write_text(
    "# Stage 8E-R1 status\n\n"
    "Complete. `STAGE_8E_T3_240D_REMAINS_CHECKPOINT`; all validation checks passed.\n"
)
