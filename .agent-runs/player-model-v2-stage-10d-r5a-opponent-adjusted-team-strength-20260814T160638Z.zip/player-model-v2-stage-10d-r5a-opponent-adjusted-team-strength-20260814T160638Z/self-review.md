[x] Terra medium verified
[x] direct Codex only; AGY/subagents unused
[x] frozen grid, sequential pre-lock updates, no 2026
[x] S30 allocation/lambda unchanged
[x] policy exception deactivated and default restored
