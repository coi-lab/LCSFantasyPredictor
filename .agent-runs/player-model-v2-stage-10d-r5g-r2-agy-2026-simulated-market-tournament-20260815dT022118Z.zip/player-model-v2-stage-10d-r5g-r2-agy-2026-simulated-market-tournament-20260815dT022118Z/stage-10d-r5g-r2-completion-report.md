# STAGE 10D-R5G-R2 2026 SIMULATED-MARKET TOURNAMENT COMPLETE REPORT

## VERDICT
- **Primary Stage Verdict**: STAGE_10D_R5G_R2_AGY_2026_SIMULATED_MARKET_TOURNAMENT_COMPLETE
- **AC Scientific Result**: AC_2026_MIXED
- **BC Sensitivity Result**: BC_2026_SENSITIVITY_WEAK
- **Prospective Candidate Status**: S30_PRIMARY_PROSPECTIVE_CANDIDATE
- **Next Node**: RETAIN_S30_AND_ARCHIVE_AC_BC_2026_RESEARCH_EVIDENCE

---

## A. Execution
Executed through AGY.
Codex was not used.
No Codex credits were required.
Worker: google / gemini-3.5-flash (High)

---

## B. Resume Authority
R5G-R1-R3 superseding resume authority was successfully verified and used.

---

## C. Quarantined Diagnostics
All prior pre-authority 2026 metrics, lineups, and round results were ignored and recomputed from scratch.

---

## D. Frozen Historical Status
AC remains the official pre-2026 pairwise finalist.
BC remains the non-finalist sensitivity comparator.
BC retroactive promotion is forbidden.

---

## E. Frozen Model Definitions
- **T3**: Validated checkpoint (t3-240d-model-artifact.json)
- **S30**: Current operational baseline
- **OATS**: K = 48, carryover = 0.75
- **B2Z-NS**: gamma = 0.40, L2 = 80.0
- **P1**: alpha = 0.70, recent_window = 15, patch_support_threshold = 20
- **AC**: S30 + delta_B + delta_O
- **BC**: S30 + delta_P + delta_O

---

## F. 2026 Round Authority
11 rounds evaluated:
- Lock-In Round 1 to 6
- Spring Round 1 to 5

---

## G. Player-Level Results
Metrics recomputed from scratch:
- **T3 Player MAE**: 5.73947 | NDCG: 0.64244
- **S30 Player MAE**: 5.73029 | NDCG: 0.63278
- **S30_OATS Player MAE**: 5.76634 | NDCG: 0.61829
- **AC Player MAE**: 5.73819 | NDCG: 0.61363
- **BC Player MAE**: 5.68969 | NDCG: 0.59924

---

## H. Role-Level Results
Role MAE comparison can be found in `stage-10d-r5g-r2-2026-role-metrics.csv`.

---

## I. Round-by-Round Fantasy Results
Detailed scores and costs can be found in `stage-10d-r5g-r2-2026-round-matrix.csv`.

---

## J. Cumulative Scoreboard
- **T3 Score**: 1449.34
- **S30 Score**: 1486.9
- **S30_OATS Score**: 1432.61
- **AC Score**: 1454.64
- **BC Score**: 1419.91
- **AC minus S30 Delta**: -32.26
- **BC minus S30 Delta**: -66.99

---

## K. AC Head-to-Head
AC vs S30 Record: 3 wins, 5 losses, 3 ties.

---

## L. BC Sensitivity
BC vs S30 Record: 2 wins, 6 losses, 3 ties.

---

## M. Roster Differences
AC vs BC average roster change count: 1.73 players per week. Same roster weeks: 3.

---

## N. Budget Behavior
Unused gold statistics:
- **AC Mean Unused Gold**: 8.85 gold
- **S30 Mean Unused Gold**: 14.76 gold

---

## O. Leaderboard Comparison
- **Winner Score**: 1572.90
- **User Score**: 1404.69
- **AC Gap to Winner**: -118.26
- **AC Gap to User**: 49.95

---

## P. AC Classification
Applying the pre-frozen rules, AC is classified as: **AC_2026_MIXED**.

---

## Q. BC Sensitivity Classification
Applying the pre-frozen rules, BC is classified as: **BC_2026_SENSITIVITY_WEAK**.

---

## R. Non-Retroactivity
R5E remains unchanged.
AC remains the official pre-2026 finalist.
BC was not retroactively promoted.

---

## S. Prospective Candidate
Prospective Candidate Status: **S30_PRIMARY_PROSPECTIVE_CANDIDATE**.

---

## T. Operational Status
T3_240d remains the validated checkpoint.
S30 remains the operational baseline unless a later explicit operationalization stage changes it.

---

## U. Reproducibility
Two-run equality check: **PASS** (lineups and scores are identical).

---

## V. Next Node
Next Node: **RETAIN_S30_AND_ARCHIVE_AC_BC_2026_RESEARCH_EVIDENCE**
