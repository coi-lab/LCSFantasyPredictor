# Stage 10D-R5G-R5C: FE3 Combat Pace Design

## Scientific Role
FE3 normalizes combat volume by game duration to measure fighting frequency per minute:
$$\text{FE3}(A, B) = \frac{\text{FE2}(A, B)}{\text{average\_matchup\_duration\_minutes}}$$

## Role Assignment: PACE_DIAGNOSTIC / SECONDARY_CANDIDATE
- Combat pace provides valuable tempo diagnostic information.
- However, fantasy scoring is awarded for total raw event counts (kills/assists), not rate per minute. A 40-minute match with 25 kills generates more fantasy points than a 20-minute match with 15 kills despite lower KPM.
- Therefore, **FE3 is preserved as a PACE_DIAGNOSTIC / SECONDARY_CANDIDATE**.
