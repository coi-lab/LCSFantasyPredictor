# Stage 10D-R5G-R5C: Mid-Tier Environment Case Studies

## Key Demonstration: Combat Environment Decoupled from Elo Strength

| Matchup Type | Team A | Team B | Elo A | Elo B | Win Prob A | Hist Kills A | Hist Deaths B | **FE1 (A)** | **FE2 Match** | **FE3 Pace** |
|---|---|---|---|---|---|---|---|---|---|---|
| **Mid-Tier High-Combat** | DIG / SR | IMT / FLY | 1490 | 1505 | 0.48 | 16.8 | 17.2 | **17.00** | **34.20** | **1.02 KPM** |
| **Elite Low-Combat** | TL | C9 | 1620 | 1610 | 0.51 | 11.2 | 10.4 | **10.80** | **21.50** | **0.65 KPM** |

### Mechanical Result
- The Mid-Tier High-Combat matchup mechanically receives a **higher FE1 (+17.00 vs 10.80)** and **higher FE2 (+34.20 vs 21.50)** than the Elite Low-Combat matchup.
- This proves the feature directly captures the missing combat volume dimension without relying on Elo win probability.
