# Stage 10D-R5G-R5C: Cold-Start & Missing History Specification

## Deterministic Neutral Fallbacks
When a team or opponent has 0 completed games in the current split:
- `historical_team_kills` = 12.60 (LEAGUE_MEAN_KILLS)
- `historical_team_deaths` = 12.60 (LEAGUE_MEAN_DEATHS)
- `historical_duration` = 1987.0 seconds (~33.1 minutes)
- Resulting `FE1(A, B)` = 12.60 (Neutral baseline expectation)
- Resulting `FE2(A, B)` = 25.20 (Neutral baseline expectation)
- Resulting `FE3(A, B)` = 0.76 KPM (Neutral baseline expectation)
