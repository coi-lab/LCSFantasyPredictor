# Stage 10D-R5G-R5C: Game Volume Policy Audit

## Policy Invariants
- All prediction periods are scored on a per-series basis.
- Per Stage 10D Phase F and prior governance, fantasy predictions must remain series-format neutral.
- No post-lock realized game counts or ungrounded match-length multipliers are permitted.
