# Stage 10D-R5G-R5C: FE2 Combined Kill Environment Design

## Scientific Role
FE2 measures total expected matchup bloodiness:
$$\text{FE2}(A, B) = \text{FE1}(A, B) + \text{FE1}(B, A) = \frac{\text{kills}(A) + \text{deaths}(B) + \text{kills}(B) + \text{deaths}(A)}{2}$$

## Role Assignment: MATCHUP_DIAGNOSTIC / CONTEXT
- FE2 is mathematically the exact sum of the two team-specific FE1 values ($\text{FE2} = \text{FE1}_A + \text{FE1}_B$).
- Advancing both FE1 and FE2 as separate additive regression features would be completely collinear / redundant.
- Therefore, **FE1 is the PRIMARY_TEAM_FEATURE**, while **FE2 is designated as a MATCHUP_DIAGNOSTIC**.
