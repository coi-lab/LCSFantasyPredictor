# Parent R2A audit

The supplied R2A normalization has core primary coverage of **116/140 (82.86%)** for matchup, roster, usage, and team-strength context.  It is 75/99 (75.76%) for 2025 and 41/41 (100%) for 2026. Patch labels had 0 usable labels (release dates were null); series opportunity and opponent-role each had 0 rows.

The old register’s 0.85641 is 167/195 across primary plus robustness rows, not primary coverage. It must not be labelled `coverage_primary`. The parent packet did not provide all requested R2A validation, focused-test, or determinism artifacts; this remediation supplies them.
