# Stage 10D-R5G-R5F: 2026 High-Combat Case Studies

## Deterministic Case Studies from 2026 Tournament

### Case 1: Lock-In Round 5 (Mid-Tier High-Combat Breakthrough)
- **Matchup Context:** Mid-tier aggressive teams in high kill-pace environment.
- **AC Lineup Output:** Selected standard safe favorites. Realized Round Score = **117.50 points**.
- **AC_FE Lineup Output:** Identified high-kill environment opportunities. Realized Round Score = **150.27 points** (**+32.77 points gain!**).

### Case 2: Lock-In Round 2 (Combat Environment Realignment)
- **AC Realized Score:** **111.60 points**.
- **AC_FE Realized Score:** **125.94 points** (**+14.34 points gain!**).

### Case 3: Lock-In Round 4
- **AC Realized Score:** **125.36 points**.
- **AC_FE Realized Score:** **136.22 points** (**+10.86 points gain!**).

### Overall Cumulative Impact
- **AC Cumulative Score:** **1454.64 points**.
- **AC_FE Cumulative Score:** **1514.23 points** (**+59.59 points gain, +4.10% improvement**).
- **Gap to 1st Place Winner (1530.01):** Reduced from **75.37 points** down to **15.78 points**.
