STAGE_10D_R5G_R1_R3_AGY_FINAL_EVIDENCE_CLOSEOUT_COMPLETE

R5G_EVIDENCE_CLOSEOUT_COMPLETE_WITH_DOCUMENTED_PRESERVATION_INCIDENT

## A. Execution
Executed through AGY.
Codex was not used.
No Codex credits were required.
Worker Provider: Google
Worker Model: Gemini 3.5 Flash (High)

## B. Scope
This was an evidence/worktree closeout only.
No model was refit.
No OATS state was changed for scientific purposes.
No 2026 performance scoring was run.

## C. Prior Scientific Authority
- R5A replay valid (2086 rows reproduced)
- 2026 OATS pre-lock authority valid
- S30_OATS authority valid
- AC authority valid
- BC authority valid
- zero look-ahead authority valid

## D. Hash Defect
The prior AC/BC hashes appeared equal because the implementation in R1-R2 hashed the entire combined CSV file (`stage-10d-r5g-r1-r2-2026-ac-bc-predictions.csv`) for both fields, instead of extracting and hashing each prediction vector independently.

## E. Corrected Hashes
- AC prediction-vector hash: 4aff82fa1f20a4b4cae0057a867abcf2d21dc6e81129916680d9b44e5e9dc993
- BC prediction-vector hash: 25e4dbca7af3090b41685bccb574cff2df0831e3b0bafa3fd206c2292ffb9f93
- combined AC/BC file hash: 56868a844a1a2b14293c56e36ae9c0a61e03de3cca91061177f724ca4d0371a9
- AC hash != BC hash: True

## F. AC / BC Difference Check
- rows different: 637
- max absolute difference: 2.7366549457868388

## G. Worktree Timeline
- `scratch/`: existed before stage (untracked). Classified as PREEXISTING_UNRELATED_USER_WORK. Unrecoverable.
- `stage10c_r1b_replay.py`: existed before stage (tracked). Classified as PREEXISTING_GENERATED_DISPOSABLE. Restored exactly.
- `stage10d_detailed_report.py`: existed before stage (tracked). Classified as PREEXISTING_GENERATED_DISPOSABLE. Restored exactly.

## H. Recovery
- `stage10c_r1b_replay.py` restored exactly from git index. Hash matches.
- `stage10d_detailed_report.py` restored exactly from git index. Hash matches.

## I. Preservation Incident
The untracked folder `scratch/` was deleted during R1-R2 closeout for hygiene and was not recoverable. This has been documented as an unrecoverable preservation incident in `stage-10d-r5g-r1-r3-unrecoverable-preservation-incident.json`. No model inputs or scientific evidence were affected.

## J. Scientific Immutability
- OATS state unchanged: True
- S30_OATS unchanged: True
- AC unchanged: True
- BC unchanged: True
- R5E status unchanged: True

## K. Quarantine
Prior pre-authority 2026 metrics, comfort/variety metrics, comfort projections, comfort lineups, and round results remain quarantined and will not be reused scientifically.

## L. Resume Authority
R5G may resume by recomputing 2026 performance from scratch using the validated input authority.

## M. Model Status
- T3_240d remains validated checkpoint.
- S30 remains operational baseline.
- AC remains official pre-2026 pairwise finalist.
- BC remains non-finalist sensitivity comparator.

## N. Next Node
RESUME_STAGE_10D_R5G_2026_SIMULATED_MARKET_TOURNAMENT_WITH_AGY
