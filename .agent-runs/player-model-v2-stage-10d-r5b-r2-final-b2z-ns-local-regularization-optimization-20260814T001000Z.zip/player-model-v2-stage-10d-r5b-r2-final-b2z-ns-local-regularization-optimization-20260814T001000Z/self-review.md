[x] Terra medium verified
[x] direct Codex only
[x] AGY not invoked; no agents/subagents
[x] fixed 12-cell search
[x] SUPPORT and team totals protected
[x] 2026 excluded
[x] final B2Z-NS frozen
