# Stage 10D-R3 BOT/SUP analyst report

## BOT_SPEC

Freeze `BOT_CARRY_PRIORITY_240`. From strictly prior player-games derive gold share, damage share, and player share of positive team fantasy production. Use fixed 240-day decay, current-team weight 1, transferred-history weight 0.5, and shrinkage 5 toward development BOT priors. Blend player and current-team BOT-slot posteriors using cutoff-safe team continuity; absent continuity favors the team-slot prior. Robustly normalize within development and define `C_BOT = mean(z(gold), z(damage), z(fantasy_share))`.

Use the single interaction `J_BOT = C_BOT * (2p_win-1)`. Fit fixed-alpha-2 ridge without intercept on 2022–2023 BOT residuals using `C_BOT` and `J_BOT`. Missing matchup neutralizes the interaction. Require at least two modalities with effective evidence or return S30. Qualify only with at least 80% complete coverage overall and 70% per 2024 split, at least 0.10 improvement in untouched 2024 MAE and RMSE, non-degrading Spearman/bias/SD ratio/Recall@3, and stable development signs/split directions.

## SUP_SPEC

Freeze `SUP_PARTICIPATION_ENVIRONMENT_240`, distinct from BOT resource coefficients. Derive prior support KP `(K+A)/teamkills` for valid denominators and support-slot participation, using the same cutoff/decay/transfer/shrinkage rules. Robustly normalize and define `P_SUP = mean(z(KP), z(participation))`.

Define pre-lock BOT companion `B_BOT = mean(z(S30_BOT), C_BOT)` and team environment `E = mean(z(log1p(max(T3_team_total,0))), 2p_win-1)`. Attenuate with cutoff-safe continuity and effective current-team SUP/BOT history: `q = continuity * sqrt(r_SUP*r_BOT)`. Interaction: `J_SUP = q * P_SUP * mean(B_BOT,E)`. Fit fixed-alpha-2 ridge without intercept on 2022–2023 SUP residuals using `P_SUP` and `J_SUP`. Missing teammate/team/matchup/continuity neutralizes the interaction; missing both participation primitives returns S30. Apply the BOT metric/coverage gate on SUP rows and require joined feature coverage.

## REJECTED_IDEAS

- Named carry teams or duos, manual styles, reusing BOT resource weights for SUP, raw CS/kill share without denominator audit, generic R2B corrections, same-week teammate scores, realized game count/duration/draft/objectives/result, hyperparameter grids, nonlinear models, or subset sweeps.

Development contains about 401 BOT and 398 SUP rows, but existing R2 context is pair-scoped and does not prove joined family coverage. Stable IDs, reconstructed-label provenance, and research-only historical S30 provenance are mandatory.
