# Stage 10D-R3 team/TOP analyst report

## GENERAL_TEAM_SPEC

Freeze `GT_SURPRISE_ENV_240`: a team-pool residual correction allocated by frozen S30 implied shares. For each completed historical series strictly before target cutoff, derive a majority-games result `y`; exclude tied, incomplete, multi-opponent, and ambiguous series. Obtain both teams' last common cutoff-safe strength snapshot and use the frozen Stage-8 probability mapping `p = logistic(3.6656880807869077 * strength_diff)`. Define surprise `u = y - p`.

Use fixed 240-day exponential decay and shrink effective history with `n/(n+5)`. Features are: shrunken last surprise, shrunken decayed surprise form, shrunken prior opponent difficulty `1-p`, schedule easing `recent_difficulty - current_opponent_strength`, and a team fantasy-environment residual. The environment is prior reconstructed usable player-game fantasy points summed per team and averaged per game, residualized against `a + b*p`, with `a,b` learned inside each 2022–2023 training fold only.

Standardize inside each rolling-origin development fold. Fit a fixed-alpha-10 ridge with intercept to team-period residual total `sum(actual-S30)`. Allocate the predicted team correction using nonnegative S30 implied shares; use equal shares only if their denominator is zero. No history maps to neutral values; missing current matchup makes schedule easing zero.

Apply identically to all roles; MID receives no separate correction. Qualify only with at least 80% meaningful coverage overall and 70% per role in development and 2024; improving development MAE/RMSE, no 2024 reversal, controlled protected metrics, at least three roles improving MAE, and no role worsening MAE over 2%. Exact same-snapshot/source-timestamp validation is mandatory.

## TOP_SPEC

Freeze `TOP_RESOURCE_PRIORITY_240`. From strictly prior TOP player-games derive gold share and CS share (`player total CS / valid team total CS`). Use 240-day decay, current-team weight 1, transferred-history weight 0.5, and shrinkage 5 to development-fold TOP priors. Standardize each component within the training fold and define `RP = 0.5*z(gold_share) + 0.5*z(cs_share)`. Missing components contribute zero after prior shrinkage; both missing returns S30.

Fit TOP residuals only with fixed-alpha-10 ridge with intercept: `actual-S30 ~ RP`. Require 80% of TOP targets with one component and 70% with both, development and 2024 MAE/RMSE non-reversal, and protected Spearman, SD-ratio, bias, and role-recall tolerances.

## REJECTED_IDEAS

- Raw win streaks, refitted probability coefficients, decay grids, per-role general-team coefficients, surprise-by-role interactions, nonlinear models, and subset sweeps.
- TOP damage share, kill share, KP, and lane-outcome proxies, which broaden the resource-priority question.
- Same-week teammate shares, target series length/objectives/result/duration, name-based joins, incomplete series, or exposed-outcome selection.

Coverage audit: 2024 canonical matchup/strength and team-fantasy source coverage appears sufficient, while the pair-scoped R2 usage table does not prove full stable-ID TOP coverage. Stage-4C strength remains provisional, reconstructed labels are non-official, and historical S30 extensions must retain research-only provenance.
