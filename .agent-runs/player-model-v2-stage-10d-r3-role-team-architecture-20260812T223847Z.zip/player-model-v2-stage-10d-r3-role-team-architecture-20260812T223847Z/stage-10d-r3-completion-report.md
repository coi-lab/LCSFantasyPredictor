# Stage 10D-R3 completion report

Verdict: `STAGE_10D_R3_NO_STRUCTURAL_ROLE_IMPROVEMENT`

Next node: `RETURN_TO_STAGE_10D_R2C_TOP2_OPTIMIZER_DIAGNOSTIC`

The frozen experiment evaluated 3,972 identical-row observations: 1,992 development rows from 2022–2023, 675 historical-robustness rows from 2024, and exposed diagnostic sets of 668 rows in 2025 and 637 rows in 2026. Positive `delta_vs_S30` means lower candidate MAE; negative means worse MAE.

## Completion questions

1. **Did Terra Low/Medium routing work as configured?** Yes. Both smoke tasks and every substantive task completed. Static configuration and terminal validation prove the requested Terra model/effort assignments; live child metadata was unavailable, so the routing status is `ROUTING_CONFIG_VALIDATED_RUNTIME_METADATA_UNAVAILABLE`.
2. **How many Sol/Terra agent calls were used?** One Sol High primary session, zero Sol child calls, and 10 Terra task turns: two routing-smoke turns, one substantive scout, three substantive analysts, one worker pass, one focused worker retry, one validator pass, and one validator rerun. No Luna calls occurred.
3. **Did expected-result adjustment improve team state?** No. The bundled team family worsened MAE by 0.081 in development and 0.199 in 2024 and was `UNSTABLE`.
4. **Did schedule easing identify legitimate bounce-back environments?** Not robustly. Its frozen implementation was cutoff-safe, but the team family failed development, 2024, protected-metric, and role-breadth gates; no independent predictive bounce-back claim is supported.
5. **Did losses to weaker-than-expected opponents receive stronger negative state?** Mechanically yes: prior series use `result - pre-series probability`, so an unexpected loss is more negative than an expected hard loss. That construction did not yield a qualified predictive family.
6. **Did TOP resource priority add predictive value?** Not consistently. It was almost flat/worse in development (`delta_vs_S30=-0.0013`) and modestly better in 2024 (`+0.0252`), with protected metrics failing; label `UNSTABLE`.
7. **Did JGL team enablement add predictive value?** Not qualified. It was nearly flat/worse in development (`-0.0010`) and modestly better in 2024 (`+0.0400`), but complete coverage was only 23/397 development rows and 47/135 2024 rows; label `BLOCKED_BY_COVERAGE`.
8. **Was JGL more tied to MID or BOT environment?** Not established. Separate coupling was implemented, but coverage failed far below the 80% gate, so coefficient interpretation is not defensible.
9. **Did BOT carry priority amplify favorable-matchup fantasy production?** No robust evidence. It worsened MAE in development (`-0.0302`) and 2024 (`-0.0282`) and failed development, 2024, and protected gates; label `UNSTABLE`.
10. **Did SUP participation environment add signal?** Not qualified. Its joined coverage was 20/398 in development and 47/135 in 2024; label `BLOCKED_BY_COVERAGE`.
11. **Did any family qualify on non-exposed evidence?** No. TEAM, TOP, and BOT were `UNSTABLE`; JGL and SUP were `BLOCKED_BY_COVERAGE`.
12. **What happened in exposed 2025?** `EXPOSED_DIAGNOSTIC_ONLY`: MAE deltas were TEAM -0.283, TOP -0.033, JGL +0.013, BOT -0.032, and SUP +0.007. These results did not change any definition or label.
13. **What happened in exposed 2026?** `EXPOSED_DIAGNOSTIC_ONLY`: MAE deltas were TEAM -0.252, TOP -0.018, JGL -0.008, BOT -0.045, and SUP +0.058. SUP's exposed improvement cannot overcome failed non-exposed coverage.
14. **Was a combined candidate justified?** No. Zero individual families qualified, so `R3_COMBINED` and the end-to-end diagnostic were skipped without a subset sweep.
15. **Did R3 explain any rank-3–4 Oracle misses?** `NOT VERIFIED`. No canonical Oracle-pair population was named in the frozen inputs, so the optional explanation was not run.
16. **Should Player Model structural research continue?** Not as the next node. Return to the TOP2 optimizer diagnostic.

## Final family labels

| Family | Development MAE / RMSE | 2024 MAE / RMSE | Label |
|---|---:|---:|---|
| R3_TEAM | 5.1406 / 6.4322 | 5.4681 / 6.5994 | `UNSTABLE` |
| R3_TOP | 4.2571 / 5.4678 | 4.2992 / 5.3598 | `UNSTABLE` |
| R3_JGL | 5.5470 / 6.7718 | 5.4891 / 6.5268 | `BLOCKED_BY_COVERAGE` |
| R3_BOT | 5.5774 / 7.0871 | 5.8357 / 6.8638 | `UNSTABLE` |
| R3_SUP | 4.9348 / 6.0560 | 5.2126 / 6.3300 | `BLOCKED_BY_COVERAGE` |

## Validation and restoration

- Terminal read-only validator: `PASS` after the one permitted focused worker retry.
- R3 tests: 11 passed. Harness-policy tests: 28 passed.
- Compileall, diff check, frozen hashes, artifact reconciliation, and two-run determinism: passed.
- The exception is inactive, concurrency is restored to one, original default model settings are restored, temporary profiles are removed, and unauthorized write agents equal zero.
- Supplemental repository-wide suite: 1,036 tests ran with 3 failures and 12 errors unrelated to R3. They came from absent optional `sklearn`/`joblib`, pre-existing legacy frozen-hash drift, and two pre-existing tracked root files failing hygiene checks. No R3 test failed, and no unrelated file was altered or removed to mask these results.

S30 remains unchanged.
T3_240d remains unchanged.
No research candidate was promoted.
