# Stage 10D-R3 shared agent brief

## Research question

Test whether cutoff-safe team fantasy environment and role-specific resource or teammate structure adds residual player-fantasy signal beyond frozen S30. This is research only; no candidate may be promoted.

## Canonical inputs

- Frozen S30 operational definition: `data/predictions/player_model_v2/evaluation/stage-9e-s30-operationalization.json`.
- Frozen T3_240d checkpoint: `data/predictions/player_model_v2/evaluation/stage-8-development-selection.json`.
- Canonical Stage 3E table: `data/processed/player_model_v2/stage_3e_03/modeling_table.csv`, with its prediction-period, prelock-feature, realized-label, feature-provenance, and chronological-partition companion tables.
- Prior role/context evidence: Stage 10D-R2B and Stage 10D-R2A-R2 tracked summaries.
- Existing team/matchup logic: `fantasy_prediction/team_strength_v2.py`, `fantasy_prediction/shared_matchup_probability.py`, and `data/predictions/player_model_v2/evaluation/stage-8-matchup-features.csv`.
- Use the repository manifest for exact columns and reusable functions.

## Partition rules

- 2022–2023: development and fitting.
- 2024: historical robustness / consumed evidence; it may support a predefined qualification assessment but must not trigger post-hoc feature expansion.
- 2025 and 2026: `EXPOSED_DIAGNOSTIC_ONLY`; never select features, coefficients, decay, thresholds, or interactions from their outcomes.
- Preserve identical observation IDs, targets, cutoffs, preprocessing, missing-data policy, and metric definitions between S30 and an R3 arm.

## Cutoff rules

- Every feature for target cutoff `t` must use source events with timestamp strictly `< t`.
- Expected-result surprise for historical series is actual completed result minus the pre-series probability that existed before that historical series.
- Same-week realized teammate scores, target objectives, target result, target duration, and any post-lock roster/draft/outcome field are forbidden.
- Historical rolling or joint-performance state must update only after the current target has been predicted.
- Current opponent and scheduled matchup may be used only when structurally known before lock.

## Common metrics and qualification

- Report MAE, RMSE, Spearman, prediction-SD/actual-SD ratio, residual bias, and defensible role-ranking recall by role, split, and season, plus deltas versus S30.
- Family labels are exactly: `QUALIFIED_FOR_RESEARCH_COMBINATION`, `PROMISING_EXPOSED_ONLY`, `NO_INCREMENTAL_SIGNAL`, `UNSTABLE`, or `BLOCKED_BY_COVERAGE`.
- Qualification comes only from permitted non-exposed evidence. An improvement only in 2025/2026 is `PROMISING_EXPOSED_ONLY`.
- Freeze at most one general-team, TOP, JGL, BOT, and SUP family. MID remains S30 plus a globally qualified general team layer, with no forced MID-specific arm.

## Forbidden behavior

- No exposed-year tuning, Oracle-membership training, combinatorial subset sweep, hard-coded teams, boosted-tree search, neural networks, or large hyperparameter sweep.
- Do not alter S30, T3_240d, production defaults, optimizer behavior, market data, or raw data.
- Do not delegate or modify repository files. Analysts provide compact specifications and rejected ideas only.
