# Stage 10D-R3 JGL analyst report

Use strict pre-cutoff events, fixed 240-day decay, effective-history shrinkage 5, and robust development-fold normalization. Current advantage is `A=2p-1`. Prior form is the decayed mean of historical `result - pre-series p`; schedule easing compares current `p` with decayed historical `p`. Prior JGL KP moderates enablement. No objective-control variable qualifies because a canonical cutoff-safe source is absent.

MID and BOT strength are pre-lock average-tie role percentiles of S30 among eligible same-period players. Any reconstructed historical S30 retains research-only provenance. Opponent JGL environment is a shrunken prior-only `3K-D+2A` proxy against the current opponent; no target result or same-week teammate realization is allowed.

Freeze the separate-coupling family rather than a pooled composite:

`G = mean(z(A), z(form), z(schedule_easing), z(opponent_JGL_environment))`

`h = (1 + z(prior_JGL_KP))/2`

`X_MID = z(h * G * MID_strength_percentile)`

`X_BOT = z(h * G * BOT_strength_percentile)`

Fit only two fixed-alpha-1 ridge coefficients without intercept on 2022–2023 JGL residuals. Missing current probability/non-strict provenance/unknown opponent returns S30. Missing history gives neutral form/easing/opponent/KP; missing teammate projection yields a strictly prior role expectation or a zero interaction, never a target outcome.

Qualify only with at least 80% complete stable-ID coverage per development fold and in 2024, favorable development OOF MAE/RMSE evidence, favorable untouched 2024 MAE/RMSE, and protected Spearman, JGL top-2 recall, bias, and SD-ratio tolerances. Coverage failure is `BLOCKED_BY_COVERAGE`; metric failure is `NO_INCREMENTAL_SIGNAL` or `UNSTABLE`.

Rejected: pooled MID/BOT composite, duplicated probability plus strength-difference inputs, objective proxies, global additive KP, TOP/SUP expansion, team realized target production, target-week teammate score, un-decayed history, and exposed tuning. Existing R2 opponent/JGL coverage and reconstructed 2024 S30 coverage are sparse, so broader cutoff-safe reconstruction may be required.
