# Stage 10D-R3 repository manifest

| Surface | Canonical path(s) | Symbols / columns |
|---|---|---|
| Historical team strength | `data/processed/player_model_v2/stage_4c_context_03/historical_team_strength.csv`; `fantasy_prediction/player_model_v2_stage4c_context_builder.py` | `materialize()`; `team_id`, `prediction_period_id`, `target_cutoff`, `prior_team_strength`, `prior_team_state`, `team_strength_uncertainty`, `team_core_strength`, `team_role_balance`, `team_continuity`, `source_max_timestamp`, `cutoff_safe` |
| Team-strength engine | `fantasy_prediction/team_strength_v2.py` | `build_team_strength_features()`, `score_team_strength()`, `TeamStrengthStateEngine`, `TrailingWinRateBaseline`, `SequentialEloBaseline`; starter rating, weakest role, continuous core, roster continuity, role coverage, reliability, organization prior |
| Pre-series win probability | `data/predictions/player_model_v2/evaluation/stage-8-matchup-features.csv`; `fantasy_prediction/shared_matchup_probability.py`; `fantasy_prediction/team_strength_v2.py` | `prior_team_strength`, `prior_opponent_team_strength`, `matchup_strength_diff`, `predicted_team_win_probability`, `target_cutoff`; `predict_pairwise_win_probability()`, `build_shared_matchup_probability()`, `get_matchup_view_for_team()` |
| Historical game/series result | `data/processed/player_model_v2/stage_3d/games.csv`; `data/processed/player_model_v2/stage_3d/series.csv`; `data/processed/player_model_v2/stage_3d/player_game_results.csv` | `series_id`, `team_1_id`, `team_2_id`, `winner_team_id`, `actual_start_utc`; player-game `opponent_team_id`, `win_result`; series `best_of`, `series_status` |
| Team fantasy production | `fantasy_prediction/stage9da_team_production_share.py`; `data/predictions/player_model_v2/evaluation/stage-9b-player-elo-history.csv` | `build()` derives team actual fantasy points by `prediction_period_id, team_id`, player team share, and role-adjusted history |
| Player fantasy labels | `data/processed/player_model_v2/stage_3e_03/realized_labels.csv`; `postperiod_player_game_results.csv`; `label_components.csv` | `realized_fantasy_points`, `games_scored`, aggregation and provenance; `reconstructed_game_points`, `label_usable` |
| Usage/share inputs | Raw yearly Oracle's Elixir CSVs; `data/processed/player_model_v2/stage_10d_r2a_r2_context/player_usage_context.csv`; `scripts/run_stage10d_r2a_r2_full_context_expansion.py` | Raw `earnedgoldshare`, `damageshare`, `total cs`, `kills`, `assists`, `teamkills`; materialized recent/long/delta gold share, damage share, KP, and `csdiffat15` |
| S30 predictions | `data/predictions/player_model_v2/s30/2026-player-predictions.csv`; `data/predictions/player_model_v2/s30/manifest.json`; `fantasy_prediction/player_share_correction.py` | `T3_prediction`, `T3_team_total`, `T3_implied_share`, `historical_share_prior`, `S30_corrected_share`, `S30_prediction`; share-prior and correction builders |
| Identity/role | `data/processed/player_model_v2/stage_3d/player_identity.csv`; `team_identity.csv`; `participation.csv` | stable player/team IDs, normalized names, `role`, validity intervals, and participation links |
| Roster continuity | `data/processed/player_model_v2/stage_10d_r2a_r2_context/roster_relationship_context.csv`; `fantasy_prediction/team_strength_v2.py::_continuity()` | `locks_with_current_team`, `recent_starter_continuity`, teammate changes; retained-player/same-role fractions |
| Opponent-role context | `data/processed/player_model_v2/stage_10d_r2a_r2_context/opponent_role_context.csv` | same-role fantasy points allowed, KP allowed, deaths created, history minimum, source timestamp |
| Period/lock mapping | `data/processed/player_model_v2/stage_3e_03/prediction_periods.csv`; `game_to_prediction_period.csv`; `champion_prediction/round_lock.py` | `prediction_period_id`, period bounds, `target_cutoff`, policy/provenance; canonical round-lock and strict-cutoff validators |

## Reusable safety and modeling code

- Cutoff safety: `data_pipeline/historical_schedule_provenance.py::revision_is_strictly_before_cutoff(), select_last_precutoff_revision()` and `fantasy_prediction/player_model_stage8d.py::validate_prelock_provenance()`.
- Chronological decay: `fantasy_prediction/player_baseline.py::recency_mean()`, `fantasy_prediction/player_model_t3_predictor.py::predict_t3_240d()`, and `fantasy_prediction/decayed_player_allocation.py::time_decay_weights(), compute_decayed_player_shares()`.
- Team core: `fantasy_prediction/team_core_features.py::build_team_core_features(), rank_projected_roster(), score_projected_player()`.
- Team/player allocation: `fantasy_prediction/team_scoring_environment.py::fit_team_environment_models(), predict_team_pools()` and `fantasy_prediction/decayed_player_allocation.py::allocate_roster_pools()`.

## Coverage/provenance caveats

- No canonical series-level winner column exists; game winners must be aggregated by `series_id` under a declared rule.
- CS share and kill share are not materialized. Raw numerators/denominators permit derivation; current R2 context exposes only `csdiffat15` and KP.
- R2 series-opportunity context leaves BO/game-count fields unqualified; cached structural mapping excludes result parsing.
- Stage 4C team strength is offline, player-derived, and structurally provisional; incomplete five-role rosters are unavailable.
- Stage 3E labels are reconstructed, non-official labels with explicit excluded components and proxies.
- Canonical S30 is the tracked 2026 artifact. Reconstructed 2024/2025 S30 extensions are research-only and noncanonical, so any use must retain that provenance label.
