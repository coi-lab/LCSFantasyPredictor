# Stage 10D-R6B: Pre-2026 Asymmetric Fantasy Environment Response Evaluation Completion Report

## VERDICT
```text
STAGE_10D_R6B_PROMOTED_SYMMETRIC_AC_FE_REMAINS_BEST
```

---

## A. Parent Baseline
`AC_FE_SYM` (history_window = 5, alpha_E = 1.690769) remains the promoted operational model from Stage 10D-R5G-R5H and Stage 10D-R6A. `AC` is permanently retained as reference baseline.

---

## B. Why Asymmetry Was Tested
In Stage 10D-R5E2, pooled confirmation suggested that positive FE adjustments were more potent. In Stage 10D-R6A walk-forward diagnostics, negative FE adjustments provided substantial error reductions. Stage 10D-R6B was authorized to explicitly test whether independently fitting positive (alpha_pos) and negative (alpha_neg) response coefficients could improve prediction quality and robustness.

---

## C. Candidate Arms Evaluated
- **ARM 0 (AC):** Unadjusted opponent-adjusted baseline (Player MAE = 5.039659, Team MAE = 22.087749).
- **ARM 1 (AC_FE_SYM):** Promoted symmetric baseline (alpha = 1.690769) (Player MAE = 5.007919, Team MAE = 21.765259).
- **ARM 2 (AC_FE_ASYM):** Fully asymmetric fit (alpha_pos >= 0, alpha_neg >= 0) (Player MAE = 5.002130, Team MAE = 21.818465).
- **ARM 3 (POS_ONLY):** Positive-only combat adjustments (alpha_neg = 0) (Player MAE = 5.049462, Team MAE = 22.040915).
- **ARM 4 (NEG_ONLY):** Negative-only low-combat penalties (alpha_pos = 0) (Player MAE = 4.992327, Team MAE = 21.865299).

---

## D. Walk-Forward Coefficients
- **Fold 1 (fit <= 2022 -> eval 2023):** alpha_pos = 0.533636, alpha_neg = 3.376470
- **Fold 2 (fit <= 2023 -> eval 2024):** alpha_pos = 0.183011, alpha_neg = 3.491112
- **Fold 3 (fit <= 2024 -> eval 2025):** alpha_pos = 1.109975, alpha_neg = 2.455670
- **Pre-2026 Overall:** alpha_pos = 0.697073, alpha_neg = 2.915783 (Ratio = 0.2391).

---

## E. Pooled Results vs Promoted Symmetric Baseline
- **Player MAE:** SYM = 5.007919 -> ASYM = 5.002130 (Delta = -0.005789 points, +0.116%).
- **Team MAE:** SYM = 21.765259 -> ASYM = 21.818465 (Delta = +0.053206 points regression).
- **Safety Gate Status:** **`FAILED`** (Team MAE regresses by +0.0532 points vs promoted symmetric baseline).

---

## F. Positive Side Analysis
- Positive combat scaling is highly volatile across seasons. In 2024, positive combat matchups generated substantial fantasy explosions (Delta = -0.182 MAE on positive rows). However, because Fold 2 had fit a small alpha_pos = 0.1830 on 2022-2023, the asymmetric model severely under-adjusted 2024 positive combat games, causing a catastrophic Fold 2 regression (+0.1099 Player MAE, +0.8178 Team MAE).

---

## G. Negative Side Analysis
- Low-combat penalties are consistently effective (alpha_neg approx 2.5 - 3.5). Negative-only corrections alone reduce player MAE to 4.9923, but at the cost of worsening team MAE (21.8653).

---

## H. Fold Stability Audit
- **Fold 1 (2023):** ASYM improves Player MAE (-0.0771) and Team MAE (-0.3652).
- **Fold 2 (2024):** ASYM **regresses severely** (+0.1099 Player MAE, +0.8178 Team MAE).
- **Fold 3 (2025):** ASYM slightly improves Player MAE (-0.0093) and Team MAE (-0.0623).
- The severe Fold 2 regression confirms that dynamic asymmetric fitting is unstable across changing season metas.

---

## I. Mid-Tier High-Combat Preservation
- On pooled walk-forward `MID_TIER - HIGH_FE` matchups (N = 496):
  - AC MAE = 5.1288, AC_FE_SYM MAE = 5.1297, AC_FE_ASYM MAE = 5.1343.
  - AC Signed Bias = -1.3038 -> SYM Bias = -0.9036 -> ASYM Bias = -1.1956.
  - The symmetric baseline achieves stronger bias reduction (+0.4002 points) than the asymmetric candidate (+0.1082 points).

---

## J. Team vs Player Consistency & R6C Motivation
- Team-level FE correction is highly effective (-0.3225 team MAE on symmetric baseline).
- However, distributing delta_E via uniform S30_share does not account for role-specific kill participation differences.
- Within-team player opportunity allocation is identified as the true remaining limitation.

---

## K. Bootstrap Robustness
- 1,000 resamples:
  - Probability(ASYM improves Player MAE) = 61.2%.
  - Probability(ASYM improves Team MAE) = 38.4% (Unfavorable).
  - The gain in player MAE is fragile and accompanied by a consistent regression in team MAE.

---

## L. 2026 Firewall
```text
2026 was not used for asymmetric coefficient fitting.
2026 was not used for model selection.
2026 candidate performance was not evaluated.
The 2026 tournament was not rerun.
```

---

## M. Model Status
```text
The promoted symmetric AC_FE remains unchanged as the operational baseline.
```

---

## N. R6C Allocation Eligibility
- **Allocation Hypothesis Supported:** `TRUE`.
- **Recommendation:** Proceed to Stage 10D-R6C to evaluate refined within-team player allocation using role/kill-participation blending.

---

## O. Next Node
```text
PROCEED_TO_STAGE_10D_R6C_PRE2026_FE_PLAYER_ALLOCATION_REASSESSMENT
```
