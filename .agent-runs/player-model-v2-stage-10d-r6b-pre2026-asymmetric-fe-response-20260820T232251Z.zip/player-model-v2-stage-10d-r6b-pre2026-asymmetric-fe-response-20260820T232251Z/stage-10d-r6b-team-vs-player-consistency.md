# Stage 10D-R6B: Team vs Player Consistency Analysis

## Summary by Fold

| Fold / Year | Model | Player MAE | Player MAE Delta vs AC | Team MAE | Team MAE Delta vs AC | Player/Team Ratio |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Fold 1 (2023)** | AC | 4.996555 | Baseline | 22.089188 | Baseline | 0.2262 |
| | AC_FE_SYM | 4.956811 | -0.039744 | 21.810124 | -0.279064 | 0.2273 |
| | AC_FE_ASYM | 4.879758 | -0.116797 | 21.444878 | -0.644310 | 0.2275 |
| **Fold 2 (2024)** | AC | 5.135939 | Baseline | 22.667470 | Baseline | 0.2266 |
| | AC_FE_SYM | 5.048371 | -0.087568 | 22.020312 | -0.647158 | 0.2293 |
| | AC_FE_ASYM | 5.158259 | +0.022320 | 22.838106 | +0.170636 | 0.2259 |
| **Fold 3 (2025)** | AC | 5.009915 | Baseline | 21.473442 | Baseline | 0.2333 |
| | AC_FE_SYM | 5.050025 | +0.040110 | 21.421884 | -0.051558 | 0.2357 |
| | AC_FE_ASYM | 5.040726 | +0.030811 | 21.359633 | -0.113809 | 0.2360 |
| **Pooled (2023-2025)** | AC | 5.039659 | Baseline | 22.087749 | Baseline | 0.2282 |
| | AC_FE_SYM | 5.007919 | -0.031740 | 21.765259 | -0.322490 | 0.2301 |
| | AC_FE_ASYM | 5.002130 | -0.037529 | 21.818465 | -0.269284 | 0.2293 |

## Findings & Allocation Hypothesis
1. **Team vs Player Inconsistency in Fold 2:** In 2024, AC_FE_ASYM suffered a massive $+0.818$ team MAE regression because historical training underestimated the positive combat regime.
2. **S30_share Allocation Limitation:** On the promoted symmetric baseline, team MAE improves by -0.3225 points (-1.46%), but player MAE improves by only -0.0317 points (-0.63%). S30_share allocates team combat opportunity equally by projected baseline share without accounting for role-specific kill participation (e.g. BOT/MID absorbing higher kill shares in bloody games while TOP/SUP absorb lower shares).
3. **Conclusion:** Within-team player allocation is the primary remaining structural bottleneck, fully motivating Stage 10D-R6C.
