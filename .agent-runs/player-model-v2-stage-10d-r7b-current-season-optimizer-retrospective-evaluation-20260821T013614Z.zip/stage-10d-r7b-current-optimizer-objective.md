# Stage 10D-R7B Current Baseline Optimizer Objective

## Mathematical Objective
Maximize projected weekly fantasy score:
max sum(PTS_i) * (1 + VarietyBuff(L))

## Constraints
1. **Roles**: Exactly 1 TOP, 1 JGL, 1 MID, 1 BOT, 1 SUP, 1 Coach (6 slots total).
2. **Budget**: Total official player & coach salaries <= 100.0g.
3. **Variety Ladder**:
   - 6 unique teams: +25%
   - 5 unique teams: +20%
   - 4 unique teams: +15%
   - 3 unique teams: +10%
   - 2 unique teams: +5%
   - 1 unique team: 0%
