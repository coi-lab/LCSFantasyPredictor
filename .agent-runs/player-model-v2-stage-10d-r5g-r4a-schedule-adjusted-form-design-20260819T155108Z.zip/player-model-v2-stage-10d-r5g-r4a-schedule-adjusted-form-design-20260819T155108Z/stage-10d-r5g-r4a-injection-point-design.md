# Stage 10D-R5G-R4A: Architectural Injection Point Design

## 1. Scientific Role Separation
The core principle is:
```text
One Component = One Scientific Responsibility
```
1. **S30:** Baseline player performance expectation (240-day decay + historical player share).
2. **OATS (`delta_O`):** Team baseline strength + target-matchup expected win probability.
3. **SAF (`delta_F`):** Schedule-adjusted recent team form (macro team-level expectation correction).
4. **B2Z-NS (`delta_B`):** Within-team non-support zero-sum role distribution.

## 2. Conceptual Future Pipeline
```text
      [ S30 Baseline Player Projections ]
                     │
                     ▼
          [ S30 Team Total Aggregation ]
                     │
                     ▼
   [ Team-Level Macro Corrections (delta_O + delta_F) ]
   - delta_O: OATS team strength & target matchup
   - delta_F: Schedule-Adjusted Form (SAF)
   Adjusted Team Total = S30_total + delta_O_team + delta_F_team
                     │
                     ▼
   [ Proportional / Share-Preserving Base Adjustment ]
   Base Player Projection = (S30_total + delta_O_team + delta_F_team) * S30_share
                     │
                     ▼
   [ B2Z-NS Role Allocation (delta_B) ]
   - Neutralized non-support zero-sum deltas
   - sum(delta_B across all 5 roles) = 0.0
   - delta_B(SUP) = 0.0 (Support protection preserved)
                     │
                     ▼
       [ Final Player Prediction (AC_SAF) ]
       AC_SAF = S30 + delta_B + delta_O + delta_F
              = AC + delta_F
```

## 3. Explicit Design Answers
- **Does SAF change team total?**
  **YES.** SAF is a team-level performance correction that adjusts the expected team fantasy production total up or down based on recent performance vs expectation.
- **Does SAF change role shares directly?**
  **NO.** Role distribution is the sole responsibility of B2Z-NS. SAF must not invent an arbitrary role-weighting or position bias.
- **Should B2Z operate before or after SAF?**
  B2Z-NS operates after team-level adjustments. Because B2Z-NS is strictly zero-sum across non-support roles (`sum(delta_B) = 0`), applying B2Z-NS adds zero net points to the team total and preserves team-total accounting perfectly.
- **How is a team-level form signal distributed to player predictions?**
  Via the baseline S30 share: `delta_F_player = delta_F_team * S30_share`.
