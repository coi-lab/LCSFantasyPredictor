# Stage 10D-R5G-R4A: Audit of Existing Matchup Coverage

## 1. Does OATS already respond to the actual upcoming opponent?
**YES.**
- In `fantasy_prediction/opponent_adjusted_team_strength.py`, the target-lock evaluation computes `oats_rating` for the subject team and `opponent_oats_rating` for the scheduled opponent.
- From these pre-lock ratings, `rating_delta = oats_rating - opponent_oats_rating` and `oats_win_probability = expected_probability(rating, opp_rating)` are directly calculated for the exact scheduled match.
- In `fantasy_prediction/s30_oats.py`, these two features (`rating_delta`, `oats_win_probability`) are the primary drivers of `delta_O_team = fit_predict(train, score, alpha=1.0)`.
- In `AC = S30_OATS + delta_B`, `delta_O` directly modulates every player's projection based on the upcoming opponent's strength.

## 2. Multi-Series & Schedule Granularity Handling
- In all 11 canonical 2026 fantasy rounds, each team plays exactly one scheduled series per round (100% 1-to-1 matching across 390 canonical rows).
- In multi-series or non-canonical formats, the schedule table maps each series to its specific scheduled opponent.
- Expected win probability and rating deltas are evaluated per scheduled match before lock.

## 3. Series Format and Expected Game Count Handling
- **NO.** Current OATS and S30 models produce per-series/per-match fantasy expectations without scaling by game count (e.g. BO1 vs BO3 vs BO5).
- This is an intentional design constraint established in Phase F policy (`EXPECTED_PROHIBITED_FEATURES` explicitly prohibits `realized_game_count_expected_games`, `game_volume_bonus`, and `expected_games_points_multiplier` to prevent volume-inflation distortion).

## 4. Synthesis and Matchup Conclusion
- **Upcoming Weekend Matchup is ALREADY_COVERED_BY_OATS.**
- Because OATS already dynamically incorporates the scheduled opponent's strength into `delta_O`, designing a second, separate additive "matchup strength" component would duplicate existing OATS coverage.
- Therefore, the focus of R4A is strictly on **schedule-adjusted recent form** (performance relative to prior expectations) rather than inventing a redundant target-matchup signal.
