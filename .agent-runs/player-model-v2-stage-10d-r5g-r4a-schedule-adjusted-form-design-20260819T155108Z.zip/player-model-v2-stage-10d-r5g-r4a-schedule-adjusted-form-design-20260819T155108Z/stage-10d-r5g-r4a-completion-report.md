# Stage 10D-R5G-R4A: Schedule-Adjusted Form and Matchup Design Completion Report

## VERDICT
```text
STAGE_10D_R5G_R4A_SAF_DESIGN_READY_MATCHUP_ALREADY_COVERED_BY_OATS
```

---

## A. Parent Authority
- **Parent Stage:** Stage 10D-R5G-R3A
- **Parent Verdict:** `STAGE_10D_R5G_R3A_AC_ALREADY_INCLUDES_OATS`
- **Verified Formulation:**
  ```text
  AC = S30 + delta_B + delta_O = S30_OATS + delta_B
  BC = S30 + delta_P + delta_O = S30_OATS + delta_P
  ```
- **Internal Consistency:** Verified. All 22 payload files match their SHA-256 manifest hashes; `state_advancement_mean_abs_effect` was recomputed directly from counterfactual rows and verified to match `2.611202619228147` exactly.

---

## B. What OATS Already Does
- **Current Team-Strength State:** Tracks dynamic pre-lock Elo ratings sequentially updated after every completed match.
- **Upcoming-Opponent Handling:** Evaluates scheduled opponent Elo pre-lock, computing `rating_delta` and `oats_win_probability`.
- **Expected Win Probability:** Fully responsive to scheduled opposition and drives `delta_O`.
- **Multi-Series Handling:** In canonical rounds, 100% of rows have 1-to-1 opponent pairings; multi-series formats map per-match opponents cleanly.
- **Series-Format Handling:** OATS is series-agnostic; Phase F policy prohibits game-volume multipliers.

---

## C. Why Raw Form Is Insufficient
- **Raw Win Rate & Raw Streak:** Confound team form with schedule difficulty.
- An 0-3 start against top-tier opponents reflects a tough schedule, whereas an 0-3 start against bottom-tier opponents reflects severe underperformance.
- Raw recent win rate unfairly penalizes middle teams facing top schedules.

---

## D. Schedule-Adjusted Form Definition
- **Core Residual Formulation:**
  ```text
  SA_result_i = actual_result_i - pre_series_expected_win_probability_i
  ```
- **Temporal Integrity:**
  - `p_i` is computed strictly using ratings available before series `i`.
  - `actual_result_i` (1 for win, 0 for loss) is recorded upon completion.
  - Series `i` is included if and only if `completed_at < target_cutoff`.

---

## E. Form Aggregation
- **Minimal Candidate Set (Bounded):**
  1. `SAF_MEAN_3`: Mean of last min(3, N) legal series residuals in current split.
  2. `SAF_MEAN_5`: Mean of last min(5, N) legal series residuals in current split (matching OATS recent_window=5).
- **Split Reset:** Resets to 0.0 at split boundary.
- **No 2026 Selection:** No lookback parameter was tuned on 2026 data.

---

## F. Streak
- **Raw Streak:** Rejected (`NO`).
- **Adjusted Streak:** Captures persistence of positive expectation residuals (`SA_result_i > 0`). Kept as `DIAGNOSTIC_ONLY`.

---

## G. Historical Strength of Schedule
- **Role:** `INPUT_TO_SAF_ONLY` / `DIAGNOSTIC_ONLY`.
- Since `SA_result_i = (y_i - 1) + (1 - p_i)`, schedule difficulty is already algebraically embedded in the residual. Adding a separate SoS feature would duplicate information.

---

## H. Upcoming Weekend Matchup
```text
ALREADY_COVERED_BY_OATS
```
- OATS already provides target-opponent dynamic responsiveness via `delta_O`.
- No additional additive matchup-strength feature is needed or authorized.

---

## I. Middle-Team Problem
- Deterministic case studies confirm:
  - Sentinels (1-2 record vs C9, FLY, TL) achieves `SAF = -0.050` (near neutral).
  - Hypothetical team (1-2 record vs bottom teams) achieves `SAF = -0.307` (severe penalty).
- Schedule adjustment mechanically solves the middle-team penalty issue.

---

## J. Double-Counting Analysis
- **Rejected Signals:**
  - `recent_raw_win_rate` (redundant & confounded)
  - `raw_w_l_streak` (redundant & confounded)
  - `additional_target_matchup_delta` (redundant with OATS)
  - `recent_raw_opponent_win_rate` (redundant with Elo probability)

---

## K. Proposed Architecture
```text
S30 -> OATS (delta_O) -> SAF (delta_F) -> B2Z-NS Allocation (delta_B) -> Player Prediction
```
- SAF operates at the team level.
- B2Z-NS non-support zero-sum allocation operates after team-level corrections, preserving total team fantasy points and support protection.

---

## L. Minimal Future Candidate (for R4B)
- **Base:** `AC`
- **New Feature:** `schedule_adjusted_recent_team_form` (`SAF_MEAN_3` or `SAF_MEAN_5`)
- **No additional matchup arm; no 2026 tuning.**

---

## M. Next Node
```text
PROCEED_TO_STAGE_10D_R5G_R4B_FROZEN_SCHEDULE_ADJUSTED_FORM_IMPLEMENTATION
```

---

## N. Freeze Status
```text
S30 remains unchanged.
S30_OATS remains unchanged.
AC remains unchanged.
BC remains unchanged.
T3_240d remains unchanged.

No new player-model arm was created.
No model was fit.
No coefficient was tuned.
No lookback was selected from 2026 performance.
No 2026 result was used for model selection.
No tournament was rerun.
No lineup result was changed.
No model was promoted or archived.
```
