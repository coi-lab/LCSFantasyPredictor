# Stage 10D-R5G-R4A: Streak Design and Specification

## 1. Why Raw W/L Streak Is Flawed
A naïve streak feature (e.g. `3 consecutive wins`) suffers from the exact same schedule-confounding problem as raw win rate:
- A 3-game win streak against 3 bottom-tier teams reflects an easy schedule, not necessarily elite form.
- A 3-game loss streak against 3 top-tier championship contenders reflects a brutal schedule, not collapse.
- Using raw W/L streak rewards easy schedules and severely penalizes difficult schedules.

## 2. Schedule-Adjusted Form Streak Semantics
Schedule-adjusted streak measures **persistence in exceeding or underperforming expectations**:
```text
SA_result_i = y_i - p_i
```
- **Positive streak:** Consecutive completed series where `SA_result_i > 0` (i.e. won when favored, or achieved upset win).
- **Negative streak:** Consecutive completed series where `SA_result_i < 0` (i.e. lost when favored, or suffered expected defeat with negative residual).
- **Directional persistence:** Count of positive residuals minus count of negative residuals in the rolling form window.

## 3. Explicit Decisions
- **Should raw W/L streak be used directly?**
  **NO.** Raw streak is confounded with schedule difficulty and violates the core design objective.
- **Can an adjusted streak capture "hot/cold relative to expectation" without rewarding an easy schedule?**
  **YES.** By counting consecutive positive residuals (`y_i - p_i > 0`), a team that beats a top team gains a positive streak increment (+0.80), while beating a bottom team gives only a tiny increment (+0.10) that can easily be snapped by any sub-par performance.
- **Recommendation:** Keep schedule-adjusted streak as a **DIAGNOSTIC_ONLY** or optional secondary metric; the primary candidate signal remains the continuous aggregated residual `SAF_MEAN_3` / `SAF_MEAN_5`.
