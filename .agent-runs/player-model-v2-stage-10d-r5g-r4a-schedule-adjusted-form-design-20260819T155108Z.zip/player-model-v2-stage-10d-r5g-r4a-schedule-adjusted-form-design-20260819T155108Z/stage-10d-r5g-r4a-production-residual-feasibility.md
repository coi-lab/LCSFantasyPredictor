# Stage 10D-R5G-R4A: Production-Based Residual Feasibility Audit

## Concept Under Investigation
A second candidate residual formulation is:
```text
realized_team_or_player_fantasy_production - pre_series_expected_fantasy_production
```

## Scientific Evaluation

### 1. Classification
```text
PROSPECTIVELY_FEASIBLE_WITH_LIMITATIONS
NOT_RECOMMENDED
```

### 2. Analysis of Circularity and Leakage
- **Point-in-time expectation reconstruction:** To reconstruct `pre_series_expected_fantasy_production` historically across 2020-2025 without data leakage, exact frozen pre-lock model tables (`S30_predictions`) for every historical series must exist. While historical modeling tables exist, they represent weekly aggregated lock periods rather than standalone pre-series snapshots for every single match.
- **Confounding factors:** Fantasy production variance is heavily contaminated by macro-game meta (game duration, total kills per game, dragon soul types, Baron takes, patch dynamics) rather than pure team performance relative to strength.
- **Model circularity:** S30 is trained on historical fantasy points. Feeding fantasy production residuals back into the model creates a recursive dependency loop with S30's decay baseline.

### 3. Comparison with Result Residual (`y_i - p_i`)
- **Result residual (`y_i - p_i`):**
  - Uses only win/loss outcomes and Elo probabilities.
  - Zero-sum: for any series between Team A and Team B, `(y_A - p_A) + (y_B - p_B) = 0.0`.
  - Directly reconstructable from sequential OATS ratings.
  - Completely orthogonal to player-level point scoring distributions.
  - Free from circular feedback loops with baseline scoring.

## Conclusion
Result residual `SA_result_i = y_i - p_i` provides a clean, elegant, leak-free, zero-sum measurement of team performance against expectation. Production-based residual introduces high variance, potential circularity, and scoring contamination without providing superior signal orthogonality. Production residual is classified as **NOT_RECOMMENDED**.
