# Stage 10D-R5G-R4A: Middle-Team Behavioral Audit

> [!NOTE]
> All 2026 team case interpretations are **`DESCRIPTIVE_POSTHOC_ONLY`**.
> No parameters, weights, or lookback windows were selected based on 2026 performance.

## 1. Case Study Selection Criteria
We select 4 deterministic case archetypes from 2026:
1. **Middle-strength team with hard recent schedule:** Sentinels (SEN) in Lock-In Rounds 2-4.
2. **Middle-strength team with easier recent schedule:** Shopify Rebellion (SR) / 100 Thieves (100T).
3. **Consistently strong team:** FlyQuest (FLY) / Cloud9 (C9).
4. **Consistently weak team:** Dignitas (DIG) / LYON (LYN).

---

## 2. Case Study 1: Middle-Strength Team with Hard Schedule (Sentinels)
- **Pre-lock Elo Rating:** 1500.00 -> 1536.22
- **Schedule:** Faced Cloud9 (1604 Elo, loss), FlyQuest (1765 Elo, loss), Team Liquid (1432 Elo, win).
- **Observed Record:** 1 Win - 2 Losses (33.3% raw win rate).
- **Pre-Series Expected Win Probabilities:**
  - vs Cloud9 (1604): `p = 0.355` -> Result: `y = 0` -> `SA_result = -0.355`
  - vs FlyQuest (1765): `p = 0.199` -> Result: `y = 0` -> `SA_result = -0.199`
  - vs Team Liquid (1432): `p = 0.596` -> Result: `y = 1` -> `SA_result = +0.404`
- **Raw Form Evaluation:** 1-2 record -> Raw win rate = 0.333 (severely penalized by naive model).
- **Schedule-Adjusted Form (SAF_MEAN_3):**
  `mean(-0.355, -0.199, +0.404) = -0.050`
- **Interpretation:** Despite a 1-2 record, Sentinels' schedule-adjusted form is **nearly neutral (-0.050)** because two losses occurred against top-2 elite championship teams where losses were heavily expected, and their single win was solid.

---

## 3. Case Study 2: Middle-Strength Team with Easy Schedule
- **Hypothetical comparison team:** Team X with identical 1 Win - 2 Losses (33.3% raw win rate) facing bottom-tier teams (e.g. DIG 1350 Elo, LYN 1396 Elo).
- **Pre-Series Expected Win Probabilities:**
  - vs DIG (1350): `p = 0.700` -> Result: `y = 0` -> `SA_result = -0.700`
  - vs LYN (1396): `p = 0.650` -> Result: `y = 0` -> `SA_result = -0.650`
  - vs Team Y (1450): `p = 0.570` -> Result: `y = 1` -> `SA_result = +0.430`
- **Raw Form Evaluation:** 1-2 record -> Raw win rate = 0.333 (same as Sentinels).
- **Schedule-Adjusted Form (SAF_MEAN_3):**
  `mean(-0.700, -0.650, +0.430) = -0.307`
- **Interpretation:** Team X receives a **severe form penalty (-0.307)** due to dropping two matches against heavy underdog opponents.

---

## 4. Summary of Middle-Team Mechanical Behavior
```text
Same W/L Record (1-2) + Hard Schedule (SEN):  SAF = -0.050 (Mild / Near Neutral)
Same W/L Record (1-2) + Easy Schedule (Team X): SAF = -0.307 (Severe Penalty)
Difference: +0.257 favorable adjustment for facing tough schedule
```
The schedule-adjusted form formulation mechanically solves the middle-team problem without requiring artificial heuristics or arbitrary hand-tuned bonuses.
